--
-- PostgreSQL database dump
--

\restrict o89AaZRmdwlbKFgXBvZnm4G8fDpqh23x9T5u3W4eZ3WgbREqJuadjpFcGeByU0v

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vehicle_types DROP CONSTRAINT IF EXISTS vehicle_types_vehicle_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_contracts DROP CONSTRAINT IF EXISTS vehicle_contracts_vehicle_company_id_fkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_contract_routes DROP CONSTRAINT IF EXISTS vehicle_contract_routes_vehicle_contract_id_fkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_companies DROP CONSTRAINT IF EXISTS vehicle_companies_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_prices DROP CONSTRAINT IF EXISTS transfer_period_regional_prices_transfer_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_prices DROP CONSTRAINT IF EXISTS transfer_period_regional_prices_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_group_ranges DROP CONSTRAINT IF EXISTS transfer_period_regional_group_ranges_transfer_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_group_ranges DROP CONSTRAINT IF EXISTS transfer_period_regional_group_ranges_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_group_ranges DROP CONSTRAINT IF EXISTS transfer_period_group_ranges_transfer_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tours DROP CONSTRAINT IF EXISTS tours_vehicle_contract_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tours DROP CONSTRAINT IF EXISTS tours_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tours DROP CONSTRAINT IF EXISTS tours_merchant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tour_sub_regions DROP CONSTRAINT IF EXISTS tour_sub_regions_tour_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tour_sub_regions DROP CONSTRAINT IF EXISTS tour_sub_regions_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tour_contract_routes DROP CONSTRAINT IF EXISTS tour_contract_routes_vehicle_contract_route_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tour_contract_routes DROP CONSTRAINT IF EXISTS tour_contract_routes_tour_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tour_contract_routes DROP CONSTRAINT IF EXISTS tour_contract_routes_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sub_regions DROP CONSTRAINT IF EXISTS sub_regions_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_country_id_fkey;
ALTER TABLE IF EXISTS ONLY public.positions DROP CONSTRAINT IF EXISTS positions_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.merchants DROP CONSTRAINT IF EXISTS merchants_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_price_periods DROP CONSTRAINT IF EXISTS fk_price_periods_contract;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS fk_contracts_vehicle_company;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS fk_contracts_tour;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS fk_contracts_sub_region;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS fk_contracts_merchant;
ALTER TABLE IF EXISTS ONLY public.contract_actions DROP CONSTRAINT IF EXISTS fk_contract_actions_contract;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.costs DROP CONSTRAINT IF EXISTS costs_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.costs DROP CONSTRAINT IF EXISTS costs_country_id_fkey;
ALTER TABLE IF EXISTS ONLY public.costs DROP CONSTRAINT IF EXISTS costs_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_tour_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_merchant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_transfer_periods DROP CONSTRAINT IF EXISTS contract_transfer_periods_contract_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_regional_prices DROP CONSTRAINT IF EXISTS contract_regional_prices_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_regional_prices DROP CONSTRAINT IF EXISTS contract_regional_prices_contract_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_price_period_regional_prices DROP CONSTRAINT IF EXISTS contract_price_period_regional_prices_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_price_period_regional_prices DROP CONSTRAINT IF EXISTS contract_price_period_regional_prices_price_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_kickback_periods DROP CONSTRAINT IF EXISTS contract_kickback_periods_contract_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_action_regional_prices DROP CONSTRAINT IF EXISTS contract_action_regional_prices_sub_region_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contract_action_regional_prices DROP CONSTRAINT IF EXISTS contract_action_regional_prices_action_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS cities_region_id_fkey;
DROP TRIGGER IF EXISTS update_vehicle_types_updated_at ON public.vehicle_types;
DROP TRIGGER IF EXISTS update_vehicle_companies_updated_at ON public.vehicle_companies;
DROP TRIGGER IF EXISTS update_tours_updated_at ON public.tours;
DROP TRIGGER IF EXISTS update_sub_regions_updated_at ON public.sub_regions;
DROP TRIGGER IF EXISTS update_regions_updated_at ON public.regions;
DROP TRIGGER IF EXISTS update_positions_updated_at ON public.positions;
DROP TRIGGER IF EXISTS update_merchants_updated_at ON public.merchants;
DROP TRIGGER IF EXISTS update_departments_updated_at ON public.departments;
DROP TRIGGER IF EXISTS update_countries_updated_at ON public.countries;
DROP TRIGGER IF EXISTS update_costs_updated_at ON public.costs;
DROP TRIGGER IF EXISTS update_cities_updated_at ON public.cities;
DROP TRIGGER IF EXISTS trigger_archive_vehicle_contracts ON public.vehicle_contracts;
DROP INDEX IF EXISTS public.idx_vehicle_types_name;
DROP INDEX IF EXISTS public.idx_vehicle_types_company_id;
DROP INDEX IF EXISTS public.idx_vehicle_contracts_dates;
DROP INDEX IF EXISTS public.idx_vehicle_contracts_company;
DROP INDEX IF EXISTS public.idx_vehicle_contracts_code;
DROP INDEX IF EXISTS public.idx_vehicle_contracts_active;
DROP INDEX IF EXISTS public.idx_vehicle_contract_routes_contract;
DROP INDEX IF EXISTS public.idx_vehicle_companies_name;
DROP INDEX IF EXISTS public.idx_vehicle_companies_city_id;
DROP INDEX IF EXISTS public.idx_users_username;
DROP INDEX IF EXISTS public.idx_users_status;
DROP INDEX IF EXISTS public.idx_users_department;
DROP INDEX IF EXISTS public.idx_users_city;
DROP INDEX IF EXISTS public.idx_transfer_regional_prices_region;
DROP INDEX IF EXISTS public.idx_transfer_regional_prices_period;
DROP INDEX IF EXISTS public.idx_transfer_regional_group_ranges_region;
DROP INDEX IF EXISTS public.idx_transfer_regional_group_ranges_period;
DROP INDEX IF EXISTS public.idx_transfer_periods_dates;
DROP INDEX IF EXISTS public.idx_transfer_periods_contract_id;
DROP INDEX IF EXISTS public.idx_transfer_periods_contract;
DROP INDEX IF EXISTS public.idx_transfer_period_regional_prices_period_id;
DROP INDEX IF EXISTS public.idx_transfer_period_regional_group_ranges_period_id;
DROP INDEX IF EXISTS public.idx_transfer_period_group_ranges_period_id;
DROP INDEX IF EXISTS public.idx_transfer_group_ranges_period;
DROP INDEX IF EXISTS public.idx_tours_vehicle_contract_id;
DROP INDEX IF EXISTS public.idx_tours_sub_region_id;
DROP INDEX IF EXISTS public.idx_tours_sejour_tour_code;
DROP INDEX IF EXISTS public.idx_tours_name;
DROP INDEX IF EXISTS public.idx_tours_merchant_id;
DROP INDEX IF EXISTS public.idx_tours_id;
DROP INDEX IF EXISTS public.idx_tours_dates;
DROP INDEX IF EXISTS public.idx_tour_sub_regions_tour_id;
DROP INDEX IF EXISTS public.idx_tour_sub_regions_sub_region_id;
DROP INDEX IF EXISTS public.idx_tour_contract_routes_vehicle_contract_route_id;
DROP INDEX IF EXISTS public.idx_tour_contract_routes_tour_id;
DROP INDEX IF EXISTS public.idx_tour_contract_routes_sub_region_id;
DROP INDEX IF EXISTS public.idx_sub_regions_name;
DROP INDEX IF EXISTS public.idx_sub_regions_id;
DROP INDEX IF EXISTS public.idx_sub_regions_city_id;
DROP INDEX IF EXISTS public.idx_regions_name;
DROP INDEX IF EXISTS public.idx_regions_country_id;
DROP INDEX IF EXISTS public.idx_price_periods_dates;
DROP INDEX IF EXISTS public.idx_price_periods_contract_id;
DROP INDEX IF EXISTS public.idx_price_period_regional_prices_region;
DROP INDEX IF EXISTS public.idx_price_period_regional_prices_period;
DROP INDEX IF EXISTS public.idx_positions_name;
DROP INDEX IF EXISTS public.idx_positions_dept_id;
DROP INDEX IF EXISTS public.idx_merchants_sub_region_id;
DROP INDEX IF EXISTS public.idx_merchants_name;
DROP INDEX IF EXISTS public.idx_merchants_id;
DROP INDEX IF EXISTS public.idx_kickback_periods_dates;
DROP INDEX IF EXISTS public.idx_kickback_periods_contract_id;
DROP INDEX IF EXISTS public.idx_kickback_periods_contract;
DROP INDEX IF EXISTS public.idx_departments_name;
DROP INDEX IF EXISTS public.idx_departments_city_id;
DROP INDEX IF EXISTS public.idx_currencies_code;
DROP INDEX IF EXISTS public.idx_currencies_active;
DROP INDEX IF EXISTS public.idx_countries_name;
DROP INDEX IF EXISTS public.idx_costs_region_id;
DROP INDEX IF EXISTS public.idx_costs_country_id;
DROP INDEX IF EXISTS public.idx_costs_cost_code;
DROP INDEX IF EXISTS public.idx_costs_city_id;
DROP INDEX IF EXISTS public.idx_contracts_vehicle_company;
DROP INDEX IF EXISTS public.idx_contracts_tour_id;
DROP INDEX IF EXISTS public.idx_contracts_tour;
DROP INDEX IF EXISTS public.idx_contracts_sub_region_id;
DROP INDEX IF EXISTS public.idx_contracts_sub_region;
DROP INDEX IF EXISTS public.idx_contracts_price_type;
DROP INDEX IF EXISTS public.idx_contracts_merchant_tour;
DROP INDEX IF EXISTS public.idx_contracts_merchant_id;
DROP INDEX IF EXISTS public.idx_contracts_merchant;
DROP INDEX IF EXISTS public.idx_contracts_dates_range;
DROP INDEX IF EXISTS public.idx_contracts_dates;
DROP INDEX IF EXISTS public.idx_contracts_created_at;
DROP INDEX IF EXISTS public.idx_contracts_contract_code;
DROP INDEX IF EXISTS public.idx_contracts_active;
DROP INDEX IF EXISTS public.idx_contract_transfer_periods_start_date;
DROP INDEX IF EXISTS public.idx_contract_transfer_periods_end_date;
DROP INDEX IF EXISTS public.idx_contract_transfer_periods_contract_id;
DROP INDEX IF EXISTS public.idx_contract_regional_prices_sub_region_id;
DROP INDEX IF EXISTS public.idx_contract_regional_prices_sub_region;
DROP INDEX IF EXISTS public.idx_contract_regional_prices_currency;
DROP INDEX IF EXISTS public.idx_contract_regional_prices_contract_price;
DROP INDEX IF EXISTS public.idx_contract_regional_prices_contract_id;
DROP INDEX IF EXISTS public.idx_contract_price_periods_start_date;
DROP INDEX IF EXISTS public.idx_contract_price_periods_end_date;
DROP INDEX IF EXISTS public.idx_contract_price_periods_contract_id;
DROP INDEX IF EXISTS public.idx_contract_kickback_periods_start_date;
DROP INDEX IF EXISTS public.idx_contract_kickback_periods_end_date;
DROP INDEX IF EXISTS public.idx_contract_kickback_periods_contract_id;
DROP INDEX IF EXISTS public.idx_contract_actions_start_date;
DROP INDEX IF EXISTS public.idx_contract_actions_end_date;
DROP INDEX IF EXISTS public.idx_contract_actions_dates;
DROP INDEX IF EXISTS public.idx_contract_actions_contract_id;
DROP INDEX IF EXISTS public.idx_cities_region_id;
DROP INDEX IF EXISTS public.idx_cities_name;
DROP INDEX IF EXISTS public.idx_action_regional_prices_region;
DROP INDEX IF EXISTS public.idx_action_regional_prices_action;
DROP INDEX IF EXISTS public.costs_cost_code_active_unique;
ALTER TABLE IF EXISTS ONLY public.vehicle_types DROP CONSTRAINT IF EXISTS vehicle_types_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_contracts DROP CONSTRAINT IF EXISTS vehicle_contracts_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_contract_routes DROP CONSTRAINT IF EXISTS vehicle_contract_routes_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_companies DROP CONSTRAINT IF EXISTS vehicle_companies_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_contracts DROP CONSTRAINT IF EXISTS unique_contract_code_per_company;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_prices DROP CONSTRAINT IF EXISTS transfer_period_regional_prices_pkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_prices DROP CONSTRAINT IF EXISTS transfer_period_regional_pric_transfer_period_id_sub_region_key;
ALTER TABLE IF EXISTS ONLY public.transfer_period_regional_group_ranges DROP CONSTRAINT IF EXISTS transfer_period_regional_group_ranges_pkey;
ALTER TABLE IF EXISTS ONLY public.transfer_period_group_ranges DROP CONSTRAINT IF EXISTS transfer_period_group_ranges_pkey;
ALTER TABLE IF EXISTS ONLY public.tours DROP CONSTRAINT IF EXISTS tours_sejour_tour_code_key;
ALTER TABLE IF EXISTS ONLY public.tours DROP CONSTRAINT IF EXISTS tours_pkey;
ALTER TABLE IF EXISTS ONLY public.tour_sub_regions DROP CONSTRAINT IF EXISTS tour_sub_regions_tour_id_sub_region_id_key;
ALTER TABLE IF EXISTS ONLY public.tour_sub_regions DROP CONSTRAINT IF EXISTS tour_sub_regions_pkey;
ALTER TABLE IF EXISTS ONLY public.tour_contract_routes DROP CONSTRAINT IF EXISTS tour_contract_routes_tour_id_sub_region_id_key;
ALTER TABLE IF EXISTS ONLY public.tour_contract_routes DROP CONSTRAINT IF EXISTS tour_contract_routes_pkey;
ALTER TABLE IF EXISTS ONLY public.sub_regions DROP CONSTRAINT IF EXISTS sub_regions_pkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_pkey;
ALTER TABLE IF EXISTS ONLY public.positions DROP CONSTRAINT IF EXISTS positions_pkey;
ALTER TABLE IF EXISTS ONLY public.merchants DROP CONSTRAINT IF EXISTS merchants_pkey;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_pkey;
ALTER TABLE IF EXISTS ONLY public.currencies DROP CONSTRAINT IF EXISTS currencies_pkey;
ALTER TABLE IF EXISTS ONLY public.currencies DROP CONSTRAINT IF EXISTS currencies_code_key;
ALTER TABLE IF EXISTS ONLY public.countries DROP CONSTRAINT IF EXISTS countries_pkey;
ALTER TABLE IF EXISTS ONLY public.costs DROP CONSTRAINT IF EXISTS costs_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_contract_code_key;
ALTER TABLE IF EXISTS ONLY public.contract_transfer_periods DROP CONSTRAINT IF EXISTS contract_transfer_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_regional_prices DROP CONSTRAINT IF EXISTS contract_regional_prices_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_regional_prices DROP CONSTRAINT IF EXISTS contract_regional_prices_contract_id_sub_region_id_key;
ALTER TABLE IF EXISTS ONLY public.contract_price_periods DROP CONSTRAINT IF EXISTS contract_price_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_price_period_regional_prices DROP CONSTRAINT IF EXISTS contract_price_period_regional_prices_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_price_period_regional_prices DROP CONSTRAINT IF EXISTS contract_price_period_regiona_price_period_id_sub_region_id_key;
ALTER TABLE IF EXISTS ONLY public.contract_kickback_periods DROP CONSTRAINT IF EXISTS contract_kickback_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_actions DROP CONSTRAINT IF EXISTS contract_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_action_regional_prices DROP CONSTRAINT IF EXISTS contract_action_regional_prices_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_action_regional_prices DROP CONSTRAINT IF EXISTS contract_action_regional_prices_action_id_sub_region_id_key;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS cities_pkey;
ALTER TABLE IF EXISTS public.vehicle_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vehicle_contracts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vehicle_contract_routes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.vehicle_companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.transfer_period_regional_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.transfer_period_regional_group_ranges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.transfer_period_group_ranges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tours ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tour_sub_regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tour_contract_routes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sub_regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.positions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.merchants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.departments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.currencies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.costs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contracts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_transfer_periods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_regional_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_price_periods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_price_period_regional_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_kickback_periods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_actions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_action_regional_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cities ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.vehicle_types_id_seq;
DROP TABLE IF EXISTS public.vehicle_types;
DROP SEQUENCE IF EXISTS public.vehicle_contracts_id_seq;
DROP TABLE IF EXISTS public.vehicle_contracts;
DROP SEQUENCE IF EXISTS public.vehicle_contract_routes_id_seq;
DROP TABLE IF EXISTS public.vehicle_contract_routes;
DROP SEQUENCE IF EXISTS public.vehicle_companies_id_seq;
DROP TABLE IF EXISTS public.vehicle_companies;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.transfer_period_regional_prices_id_seq;
DROP TABLE IF EXISTS public.transfer_period_regional_prices;
DROP SEQUENCE IF EXISTS public.transfer_period_regional_group_ranges_id_seq;
DROP TABLE IF EXISTS public.transfer_period_regional_group_ranges;
DROP SEQUENCE IF EXISTS public.transfer_period_group_ranges_id_seq;
DROP TABLE IF EXISTS public.transfer_period_group_ranges;
DROP SEQUENCE IF EXISTS public.tours_id_seq;
DROP TABLE IF EXISTS public.tours;
DROP SEQUENCE IF EXISTS public.tour_sub_regions_id_seq;
DROP TABLE IF EXISTS public.tour_sub_regions;
DROP SEQUENCE IF EXISTS public.tour_contract_routes_id_seq;
DROP TABLE IF EXISTS public.tour_contract_routes;
DROP SEQUENCE IF EXISTS public.sub_regions_id_seq;
DROP TABLE IF EXISTS public.sub_regions;
DROP SEQUENCE IF EXISTS public.regions_id_seq;
DROP TABLE IF EXISTS public.regions;
DROP SEQUENCE IF EXISTS public.positions_id_seq;
DROP TABLE IF EXISTS public.positions;
DROP SEQUENCE IF EXISTS public.merchants_id_seq;
DROP TABLE IF EXISTS public.merchants;
DROP SEQUENCE IF EXISTS public.departments_id_seq;
DROP TABLE IF EXISTS public.departments;
DROP SEQUENCE IF EXISTS public.currencies_id_seq;
DROP TABLE IF EXISTS public.currencies;
DROP SEQUENCE IF EXISTS public.countries_id_seq;
DROP TABLE IF EXISTS public.countries;
DROP SEQUENCE IF EXISTS public.costs_id_seq;
DROP TABLE IF EXISTS public.costs;
DROP SEQUENCE IF EXISTS public.contracts_id_seq;
DROP TABLE IF EXISTS public.contracts;
DROP SEQUENCE IF EXISTS public.contract_transfer_periods_id_seq;
DROP TABLE IF EXISTS public.contract_transfer_periods;
DROP SEQUENCE IF EXISTS public.contract_regional_prices_id_seq;
DROP TABLE IF EXISTS public.contract_regional_prices;
DROP SEQUENCE IF EXISTS public.contract_price_periods_id_seq;
DROP TABLE IF EXISTS public.contract_price_periods;
DROP SEQUENCE IF EXISTS public.contract_price_period_regional_prices_id_seq;
DROP TABLE IF EXISTS public.contract_price_period_regional_prices;
DROP SEQUENCE IF EXISTS public.contract_kickback_periods_id_seq;
DROP TABLE IF EXISTS public.contract_kickback_periods;
DROP SEQUENCE IF EXISTS public.contract_actions_id_seq;
DROP TABLE IF EXISTS public.contract_actions;
DROP SEQUENCE IF EXISTS public.contract_action_regional_prices_id_seq;
DROP TABLE IF EXISTS public.contract_action_regional_prices;
DROP SEQUENCE IF EXISTS public.cities_id_seq;
DROP TABLE IF EXISTS public.cities;
DROP FUNCTION IF EXISTS public.user_has_region_permission(p_user_id integer, p_region_id integer);
DROP FUNCTION IF EXISTS public.user_has_country_permission(p_user_id integer, p_country_id integer);
DROP FUNCTION IF EXISTS public.user_has_city_permission(p_user_id integer, p_city_id integer);
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.get_active_version(table_name text, parent_id integer, check_date date);
DROP FUNCTION IF EXISTS public.get_active_for_date(table_name text, check_date date, parent_id integer);
DROP FUNCTION IF EXISTS public.archive_old_version();
DROP FUNCTION IF EXISTS public.archive_old_route();
DROP FUNCTION IF EXISTS public.archive_old_cost();
--
-- Name: archive_old_cost(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.archive_old_cost() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Deactivate old costs with the same country_id
    -- Check if is_active column exists before using it
    BEGIN
        UPDATE costs 
        SET is_active = false
        WHERE country_id = NEW.country_id 
          AND is_active = true 
          AND id != NEW.id;
    EXCEPTION
        WHEN OTHERS THEN
            -- If is_active column doesn't exist, just skip archiving
            NULL;
    END;
    
    RETURN NEW;
END;
$$;


--
-- Name: archive_old_route(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.archive_old_route() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Archive overlapping routes for same contract
    IF NEW.is_active = true AND NEW.valid_from IS NOT NULL AND NEW.valid_to IS NOT NULL THEN
        UPDATE vehicle_contract_routes 
        SET is_active = false, 
            archived_at = NOW(),
            replaced_by_id = NEW.id
        WHERE vehicle_contract_id = NEW.vehicle_contract_id 
        AND is_active = true 
        AND id != NEW.id
        AND (
            (valid_from <= NEW.valid_from AND valid_to >= NEW.valid_from) OR
            (valid_from <= NEW.valid_to AND valid_to >= NEW.valid_to) OR
            (valid_from >= NEW.valid_from AND valid_to <= NEW.valid_to)
        );
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION archive_old_route(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.archive_old_route() IS 'Automatically archives overlapping contract routes when new version is created';


--
-- Name: archive_old_version(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.archive_old_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE vehicle_contracts 
    SET is_active = false,
        archived_at = NOW(),
        replaced_by_id = NEW.id
    WHERE vehicle_company_id = NEW.vehicle_company_id
      AND is_active = true
      AND id != NEW.id
      AND ((start_date <= NEW.start_date AND end_date >= NEW.start_date) OR
           (start_date <= NEW.end_date AND end_date >= NEW.end_date) OR
           (start_date >= NEW.start_date AND end_date <= NEW.end_date));
    RETURN NEW;
END;
$$;


--
-- Name: get_active_for_date(text, date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_active_for_date(table_name text, check_date date DEFAULT CURRENT_DATE, parent_id integer DEFAULT NULL::integer) RETURNS TABLE(id integer, is_active boolean, version_number integer, valid_from date, valid_to date)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- This is a template function - actual implementation depends on table structure
    RETURN QUERY EXECUTE format('
        SELECT id, is_active, version_number, valid_from, valid_to
        FROM %I
        WHERE is_active = true
        AND (valid_from IS NULL OR valid_from <= $1)
        AND (valid_to IS NULL OR valid_to >= $1)
        ORDER BY version_number DESC
        LIMIT 1
    ', table_name) USING check_date;
END;
$_$;


--
-- Name: FUNCTION get_active_for_date(table_name text, check_date date, parent_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_active_for_date(table_name text, check_date date, parent_id integer) IS 'Helper function to get active version for a specific date';


--
-- Name: get_active_version(text, integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_active_version(table_name text, parent_id integer, check_date date DEFAULT CURRENT_DATE) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
    version_num INTEGER;
BEGIN
    EXECUTE format('
        SELECT version_number 
        FROM %I 
        WHERE is_active = true 
        AND (%s_id = $1 OR id = $1)
        AND (valid_from IS NULL OR valid_from <= $2)
        AND (valid_to IS NULL OR valid_to >= $2)
        ORDER BY version_number DESC 
        LIMIT 1
    ', table_name, parent_id) INTO version_num USING parent_id, check_date;
    
    RETURN COALESCE(version_num, 1);
END;
$_$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: user_has_city_permission(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.user_has_city_permission(p_user_id integer, p_city_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM user_permissions
        WHERE user_id = p_user_id
        AND permission_type = 'city'
        AND entity_id = p_city_id
    ) OR EXISTS (
        SELECT 1 FROM user_permissions up
        JOIN cities c ON c.id = p_city_id
        JOIN regions r ON r.id = c.region_id
        WHERE up.user_id = p_user_id
        AND up.permission_type = 'region'
        AND up.entity_id = r.id
    ) OR EXISTS (
        SELECT 1 FROM user_permissions up
        JOIN cities c ON c.id = p_city_id
        JOIN regions r ON r.id = c.region_id
        WHERE up.user_id = p_user_id
        AND up.permission_type = 'country'
        AND up.entity_id = r.country_id
    );
END;
$$;


--
-- Name: user_has_country_permission(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.user_has_country_permission(p_user_id integer, p_country_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM user_permissions
        WHERE user_id = p_user_id
        AND permission_type = 'country'
        AND entity_id = p_country_id
    );
END;
$$;


--
-- Name: user_has_region_permission(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.user_has_region_permission(p_user_id integer, p_region_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM user_permissions
        WHERE user_id = p_user_id
        AND permission_type = 'region'
        AND entity_id = p_region_id
    ) OR EXISTS (
        SELECT 1 FROM user_permissions up
        JOIN regions r ON r.id = p_region_id
        WHERE up.user_id = p_user_id
        AND up.permission_type = 'country'
        AND up.entity_id = r.country_id
    );
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cities (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    region_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cities_id_seq OWNED BY public.cities.id;


--
-- Name: contract_action_regional_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_action_regional_prices (
    id integer NOT NULL,
    action_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    adult_price numeric(10,2),
    child_price numeric(10,2),
    infant_price numeric(10,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE contract_action_regional_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_action_regional_prices IS 'Regional prices for contract actions';


--
-- Name: contract_action_regional_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_action_regional_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_action_regional_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_action_regional_prices_id_seq OWNED BY public.contract_action_regional_prices.id;


--
-- Name: contract_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_actions (
    id integer NOT NULL,
    contract_id integer NOT NULL,
    action_name character varying(255) NOT NULL,
    action_description text,
    action_start_date date NOT NULL,
    action_end_date date NOT NULL,
    action_duration_type character varying(20) DEFAULT 'day'::character varying,
    action_duration_days integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    price_type character varying(20) DEFAULT NULL::character varying,
    adult_age character varying(50),
    child_age_range character varying(50),
    infant_age_range character varying(50),
    adult_price numeric(10,2),
    child_price numeric(10,2),
    infant_price numeric(10,2),
    action_currency character varying(3),
    regional_adult_age character varying(50),
    regional_child_age character varying(50),
    regional_infant_age character varying(50)
);


--
-- Name: TABLE contract_actions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_actions IS 'Contract actions/projects with different durations';


--
-- Name: COLUMN contract_actions.action_duration_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.action_duration_type IS 'Duration type: day, week, month, custom';


--
-- Name: COLUMN contract_actions.action_duration_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.action_duration_days IS 'Duration in days (for custom periods)';


--
-- Name: COLUMN contract_actions.price_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.price_type IS 'Pricing type: fixed or regional';


--
-- Name: COLUMN contract_actions.adult_age; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.adult_age IS 'Adult age definition (e.g., 13+)';


--
-- Name: COLUMN contract_actions.child_age_range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.child_age_range IS 'Child age range (e.g., 3-12)';


--
-- Name: COLUMN contract_actions.infant_age_range; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_actions.infant_age_range IS 'Infant age range (e.g., 0-2)';


--
-- Name: contract_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_actions_id_seq OWNED BY public.contract_actions.id;


--
-- Name: contract_kickback_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_kickback_periods (
    id integer NOT NULL,
    contract_id integer NOT NULL,
    period_name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    kickback_type character varying(50),
    kickback_value numeric(10,2),
    kickback_currency character varying(10),
    kickback_per_person boolean DEFAULT false,
    kickback_min_persons integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: contract_kickback_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_kickback_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_kickback_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_kickback_periods_id_seq OWNED BY public.contract_kickback_periods.id;


--
-- Name: contract_price_period_regional_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_price_period_regional_prices (
    id integer NOT NULL,
    price_period_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    adult_price numeric(10,2),
    child_price numeric(10,2),
    infant_price numeric(10,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE contract_price_period_regional_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_price_period_regional_prices IS 'Regional prices for contract price periods';


--
-- Name: contract_price_period_regional_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_price_period_regional_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_price_period_regional_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_price_period_regional_prices_id_seq OWNED BY public.contract_price_period_regional_prices.id;


--
-- Name: contract_price_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_price_periods (
    id integer NOT NULL,
    contract_id integer NOT NULL,
    period_name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days_of_week character varying(50) DEFAULT NULL::character varying,
    adult_price numeric(10,2) DEFAULT NULL::numeric,
    child_price numeric(10,2) DEFAULT NULL::numeric,
    infant_price numeric(10,2) DEFAULT NULL::numeric,
    currency character varying(3) DEFAULT 'USD'::character varying,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    price_type character varying(20) DEFAULT 'regional'::character varying,
    adult_age character varying(50),
    child_age_range character varying(50),
    infant_age_range character varying(50)
);


--
-- Name: TABLE contract_price_periods; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_price_periods IS 'Different price periods for the same contract (e.g., high season, low season)';


--
-- Name: COLUMN contract_price_periods.days_of_week; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_price_periods.days_of_week IS 'Comma-separated weekdays: monday,tuesday,wednesday,thursday,friday,saturday,sunday or JSON array';


--
-- Name: COLUMN contract_price_periods.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_price_periods.notes IS 'Notes about this price period (e.g., High Season, Holiday Period)';


--
-- Name: contract_price_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_price_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_price_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_price_periods_id_seq OWNED BY public.contract_price_periods.id;


--
-- Name: contract_regional_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_regional_prices (
    id integer NOT NULL,
    contract_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    adult_price numeric(10,2),
    adult_currency character varying(3) DEFAULT 'USD'::character varying,
    child_price numeric(10,2),
    child_currency character varying(3) DEFAULT 'USD'::character varying,
    infant_price numeric(10,2),
    infant_currency character varying(3) DEFAULT 'USD'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE contract_regional_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_regional_prices IS 'Stores region-specific prices for contracts. Only used when contract.price_type = regional';


--
-- Name: contract_regional_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_regional_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_regional_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_regional_prices_id_seq OWNED BY public.contract_regional_prices.id;


--
-- Name: contract_transfer_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_transfer_periods (
    id integer NOT NULL,
    contract_id integer NOT NULL,
    period_name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    transfer_owner character varying(50) NOT NULL,
    transfer_price_type character varying(50),
    transfer_price numeric(10,2),
    transfer_currency character varying(10),
    transfer_price_mini numeric(10,2),
    transfer_price_midi numeric(10,2),
    transfer_price_bus numeric(10,2),
    transfer_currency_fixed character varying(10),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    pricing_method character varying(20) DEFAULT 'fixed_price'::character varying,
    fixed_price_type character varying(20),
    adult_age character varying(50),
    child_age_range character varying(50),
    infant_age_range character varying(50),
    adult_price numeric(10,2),
    child_price numeric(10,2),
    infant_price numeric(10,2),
    fixed_currency character varying(3),
    group_price numeric(10,2),
    group_currency character varying(3),
    regional_adult_age character varying(50),
    regional_child_age character varying(50),
    regional_infant_age character varying(50),
    regional_price_type character varying(20)
);


--
-- Name: COLUMN contract_transfer_periods.pricing_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_transfer_periods.pricing_method IS 'Pricing method: fixed_price or regional_price';


--
-- Name: COLUMN contract_transfer_periods.fixed_price_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_transfer_periods.fixed_price_type IS 'For fixed_price method: per_person or group';


--
-- Name: COLUMN contract_transfer_periods.regional_price_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract_transfer_periods.regional_price_type IS 'For regional_price method: per_person or group';


--
-- Name: contract_transfer_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_transfer_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_transfer_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_transfer_periods_id_seq OWNED BY public.contract_transfer_periods.id;


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    sub_region_id integer NOT NULL,
    merchant_id integer NOT NULL,
    tour_id integer NOT NULL,
    vat_included boolean DEFAULT false,
    vat_rate numeric(5,2),
    adult_age character varying(50),
    child_age_range character varying(50),
    infant_age_range character varying(50),
    kickback_type character varying(20),
    kickback_value numeric(10,2),
    kickback_per_person boolean DEFAULT false,
    kickback_min_persons integer,
    included_content text,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    price_type character varying(20) DEFAULT 'regional'::character varying,
    contract_currency character varying(3) DEFAULT 'USD'::character varying,
    fixed_adult_price numeric(10,2),
    fixed_child_price numeric(10,2),
    fixed_infant_price numeric(10,2),
    kickback_currency character varying(3),
    transfer_owner character varying(50),
    transfer_price_type character varying(50),
    transfer_price numeric(10,2),
    transfer_currency character varying(10),
    transfer_price_mini numeric(10,2),
    transfer_price_midi numeric(10,2),
    transfer_price_bus numeric(10,2),
    transfer_currency_fixed character varying(10),
    is_active boolean DEFAULT true,
    period_type character varying(20) DEFAULT NULL::character varying,
    period_value integer,
    period_unit character varying(20) DEFAULT NULL::character varying,
    tour_departure_days character varying(50) DEFAULT NULL::character varying,
    vehicle_company_id integer,
    contract_code character varying(50),
    CONSTRAINT chk_end_after_start CHECK ((end_date >= start_date)),
    CONSTRAINT chk_kickback_value CHECK (((((kickback_type)::text = ''::text) AND (kickback_value IS NULL)) OR (((kickback_type)::text = ANY ((ARRAY['fixed'::character varying, 'percentage'::character varying])::text[])) AND (kickback_value IS NOT NULL)))),
    CONSTRAINT contracts_kickback_type_check CHECK (((kickback_type)::text = ANY ((ARRAY['fixed'::character varying, 'percentage'::character varying, ''::character varying])::text[]))),
    CONSTRAINT contracts_price_type_check CHECK (((price_type)::text = ANY ((ARRAY['regional'::character varying, 'fixed'::character varying])::text[])))
);


--
-- Name: TABLE contracts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contracts IS 'Stores contract information between merchants and tours. Prices are stored in contract_regional_prices table.';


--
-- Name: COLUMN contracts.vat_included; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.vat_included IS 'Whether VAT is included in the price';


--
-- Name: COLUMN contracts.vat_rate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.vat_rate IS 'VAT rate percentage (only used if vat_included is false)';


--
-- Name: COLUMN contracts.kickback_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.kickback_type IS 'Type of kickback: fixed amount or percentage';


--
-- Name: COLUMN contracts.kickback_per_person; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.kickback_per_person IS 'Whether kickback is calculated per person or total';


--
-- Name: COLUMN contracts.kickback_min_persons; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.kickback_min_persons IS 'Minimum number of persons required for kickback';


--
-- Name: COLUMN contracts.price_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.price_type IS 'Type of pricing: regional (prices vary by region) or fixed (same price for all regions)';


--
-- Name: COLUMN contracts.contract_currency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.contract_currency IS 'Common currency for all prices in this contract (used for fixed prices and regional prices)';


--
-- Name: COLUMN contracts.fixed_adult_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.fixed_adult_price IS 'Fixed adult price applied to all regions (only used when price_type = fixed)';


--
-- Name: COLUMN contracts.fixed_child_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.fixed_child_price IS 'Fixed child price applied to all regions (only used when price_type = fixed)';


--
-- Name: COLUMN contracts.fixed_infant_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.fixed_infant_price IS 'Fixed infant price applied to all regions (only used when price_type = fixed)';


--
-- Name: COLUMN contracts.period_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.period_type IS 'Period type: monthly, quarterly, yearly, custom';


--
-- Name: COLUMN contracts.period_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.period_value IS 'Period value (e.g., 1 for monthly, 3 for quarterly)';


--
-- Name: COLUMN contracts.period_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.period_unit IS 'Period unit: day, week, month, year';


--
-- Name: COLUMN contracts.tour_departure_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.tour_departure_days IS 'Tour departure days in week (comma-separated or JSON array)';


--
-- Name: COLUMN contracts.contract_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.contract_code IS 'Unique code for each contract in format FST-YYYYMMDD-NNNN';


--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.costs (
    id integer NOT NULL,
    cost_code character varying(50) NOT NULL,
    cost_name character varying(255),
    country_id integer,
    region_id integer,
    city_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    is_active boolean DEFAULT true,
    valid_from date DEFAULT CURRENT_DATE
);


--
-- Name: COLUMN costs.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.costs.is_active IS 'True if this is the currently active version';


--
-- Name: COLUMN costs.valid_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.costs.valid_from IS 'Start date when this cost becomes valid';


--
-- Name: costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.costs_id_seq OWNED BY public.costs.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(3) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(10),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE currencies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.currencies IS 'Stores currency information';


--
-- Name: COLUMN currencies.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currencies.code IS 'ISO 4217 currency code (e.g., USD, EUR, TL)';


--
-- Name: COLUMN currencies.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currencies.name IS 'Currency name (e.g., US Dollar, Euro, Turkish Lira)';


--
-- Name: COLUMN currencies.symbol; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currencies.symbol IS 'Currency symbol (e.g., $, €, ₺)';


--
-- Name: COLUMN currencies.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.currencies.is_active IS 'Whether the currency is active and can be used';


--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    city_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merchants (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    official_title character varying(200),
    sub_region_id integer NOT NULL,
    authorized_person character varying(100),
    authorized_email character varying(100),
    authorized_phone character varying(20),
    operasyon_name character varying(100),
    operasyon_email character varying(100),
    operasyon_phone character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    location_url text
);


--
-- Name: merchants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.merchants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: merchants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.merchants_id_seq OWNED BY public.merchants.id;


--
-- Name: positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.positions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: positions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.positions_id_seq OWNED BY public.positions.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    country_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: sub_regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sub_regions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    city_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: sub_regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sub_regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sub_regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sub_regions_id_seq OWNED BY public.sub_regions.id;


--
-- Name: tour_contract_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tour_contract_routes (
    id integer NOT NULL,
    tour_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    vehicle_contract_route_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: TABLE tour_contract_routes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tour_contract_routes IS 'Links tours to vehicle contract routes by sub-regions for regional pricing';


--
-- Name: tour_contract_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tour_contract_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tour_contract_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tour_contract_routes_id_seq OWNED BY public.tour_contract_routes.id;


--
-- Name: tour_sub_regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tour_sub_regions (
    id integer NOT NULL,
    tour_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE tour_sub_regions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tour_sub_regions IS 'Many-to-many relationship between tours and sub_regions. Defines which regions a tour operates in.';


--
-- Name: tour_sub_regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tour_sub_regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tour_sub_regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tour_sub_regions_id_seq OWNED BY public.tour_sub_regions.id;


--
-- Name: tours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tours (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    sub_region_id integer NOT NULL,
    merchant_id integer NOT NULL,
    start_date date,
    end_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    sejour_tour_code character varying(50),
    vehicle_contract_id integer
);


--
-- Name: COLUMN tours.vehicle_contract_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tours.vehicle_contract_id IS 'Links tour to vehicle contract for price display. Set manually by user.';


--
-- Name: tours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tours_id_seq OWNED BY public.tours.id;


--
-- Name: transfer_period_group_ranges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_period_group_ranges (
    id integer NOT NULL,
    transfer_period_id integer NOT NULL,
    min_persons integer NOT NULL,
    max_persons integer NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE transfer_period_group_ranges; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.transfer_period_group_ranges IS 'Group-based pricing ranges for transfer periods (fixed price - group total)';


--
-- Name: transfer_period_group_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transfer_period_group_ranges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_period_group_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transfer_period_group_ranges_id_seq OWNED BY public.transfer_period_group_ranges.id;


--
-- Name: transfer_period_regional_group_ranges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_period_regional_group_ranges (
    id integer NOT NULL,
    transfer_period_id integer CONSTRAINT transfer_period_regional_group_rang_transfer_period_id_not_null NOT NULL,
    sub_region_id integer NOT NULL,
    min_persons integer NOT NULL,
    max_persons integer NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE transfer_period_regional_group_ranges; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.transfer_period_regional_group_ranges IS 'Regional group-based pricing ranges (regional price - group)';


--
-- Name: transfer_period_regional_group_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transfer_period_regional_group_ranges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_period_regional_group_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transfer_period_regional_group_ranges_id_seq OWNED BY public.transfer_period_regional_group_ranges.id;


--
-- Name: transfer_period_regional_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_period_regional_prices (
    id integer NOT NULL,
    transfer_period_id integer NOT NULL,
    sub_region_id integer NOT NULL,
    adult_price numeric(10,2),
    child_price numeric(10,2),
    infant_price numeric(10,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE transfer_period_regional_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.transfer_period_regional_prices IS 'Regional prices for transfer periods (per person pricing)';


--
-- Name: transfer_period_regional_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transfer_period_regional_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_period_regional_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transfer_period_regional_prices_id_seq OWNED BY public.transfer_period_regional_prices.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    full_name character varying(255),
    department_id integer,
    city_id integer,
    email character varying(255),
    phone character varying(50),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    password_hash text
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_companies (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    city_id integer NOT NULL,
    contact_person character varying(255),
    contact_email character varying(255),
    contact_phone character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: vehicle_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_companies_id_seq OWNED BY public.vehicle_companies.id;


--
-- Name: vehicle_contract_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_contract_routes (
    id integer NOT NULL,
    vehicle_contract_id integer,
    from_location character varying(255),
    to_location character varying(255),
    vip_mini_price numeric(10,2),
    mini_price numeric(10,2),
    midi_price numeric(10,2),
    bus_price numeric(10,2),
    price numeric(10,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: vehicle_contract_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_contract_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_contract_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_contract_routes_id_seq OWNED BY public.vehicle_contract_routes.id;


--
-- Name: vehicle_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_contracts (
    id integer NOT NULL,
    vehicle_company_id integer NOT NULL,
    contract_code character varying(100) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true,
    archived_at timestamp without time zone,
    replaced_by_id integer,
    CONSTRAINT valid_dates CHECK ((end_date >= start_date))
);


--
-- Name: TABLE vehicle_contracts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vehicle_contracts IS 'Stores basic vehicle company contract information';


--
-- Name: COLUMN vehicle_contracts.contract_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_contracts.contract_code IS 'Unique contract code per vehicle company';


--
-- Name: COLUMN vehicle_contracts.start_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_contracts.start_date IS 'Contract start date';


--
-- Name: COLUMN vehicle_contracts.end_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_contracts.end_date IS 'Contract end date';


--
-- Name: COLUMN vehicle_contracts.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.vehicle_contracts.is_active IS 'True if this is the currently active version';


--
-- Name: vehicle_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_contracts_id_seq OWNED BY public.vehicle_contracts.id;


--
-- Name: vehicle_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    vehicle_company_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


--
-- Name: vehicle_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehicle_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehicle_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehicle_types_id_seq OWNED BY public.vehicle_types.id;


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_id_seq'::regclass);


--
-- Name: contract_action_regional_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_action_regional_prices ALTER COLUMN id SET DEFAULT nextval('public.contract_action_regional_prices_id_seq'::regclass);


--
-- Name: contract_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_actions ALTER COLUMN id SET DEFAULT nextval('public.contract_actions_id_seq'::regclass);


--
-- Name: contract_kickback_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_kickback_periods ALTER COLUMN id SET DEFAULT nextval('public.contract_kickback_periods_id_seq'::regclass);


--
-- Name: contract_price_period_regional_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_period_regional_prices ALTER COLUMN id SET DEFAULT nextval('public.contract_price_period_regional_prices_id_seq'::regclass);


--
-- Name: contract_price_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_periods ALTER COLUMN id SET DEFAULT nextval('public.contract_price_periods_id_seq'::regclass);


--
-- Name: contract_regional_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_regional_prices ALTER COLUMN id SET DEFAULT nextval('public.contract_regional_prices_id_seq'::regclass);


--
-- Name: contract_transfer_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_transfer_periods ALTER COLUMN id SET DEFAULT nextval('public.contract_transfer_periods_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costs ALTER COLUMN id SET DEFAULT nextval('public.costs_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: merchants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants ALTER COLUMN id SET DEFAULT nextval('public.merchants_id_seq'::regclass);


--
-- Name: positions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions ALTER COLUMN id SET DEFAULT nextval('public.positions_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: sub_regions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_regions ALTER COLUMN id SET DEFAULT nextval('public.sub_regions_id_seq'::regclass);


--
-- Name: tour_contract_routes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes ALTER COLUMN id SET DEFAULT nextval('public.tour_contract_routes_id_seq'::regclass);


--
-- Name: tour_sub_regions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_sub_regions ALTER COLUMN id SET DEFAULT nextval('public.tour_sub_regions_id_seq'::regclass);


--
-- Name: tours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours ALTER COLUMN id SET DEFAULT nextval('public.tours_id_seq'::regclass);


--
-- Name: transfer_period_group_ranges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_group_ranges ALTER COLUMN id SET DEFAULT nextval('public.transfer_period_group_ranges_id_seq'::regclass);


--
-- Name: transfer_period_regional_group_ranges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_group_ranges ALTER COLUMN id SET DEFAULT nextval('public.transfer_period_regional_group_ranges_id_seq'::regclass);


--
-- Name: transfer_period_regional_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_prices ALTER COLUMN id SET DEFAULT nextval('public.transfer_period_regional_prices_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicle_companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_companies ALTER COLUMN id SET DEFAULT nextval('public.vehicle_companies_id_seq'::regclass);


--
-- Name: vehicle_contract_routes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contract_routes ALTER COLUMN id SET DEFAULT nextval('public.vehicle_contract_routes_id_seq'::regclass);


--
-- Name: vehicle_contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contracts ALTER COLUMN id SET DEFAULT nextval('public.vehicle_contracts_id_seq'::regclass);


--
-- Name: vehicle_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_types ALTER COLUMN id SET DEFAULT nextval('public.vehicle_types_id_seq'::regclass);


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cities (id, name, region_id, created_at, updated_at) FROM stdin;
1	Antalya	1	2025-10-26 15:18:40.16332	\N
6	Bodrum	35	2025-10-26 20:39:27.619768	\N
7	Marmaris	35	2025-10-26 20:39:37.954238	\N
\.


--
-- Data for Name: contract_action_regional_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_action_regional_prices (id, action_id, sub_region_id, adult_price, child_price, infant_price, is_active, created_at, updated_at) FROM stdin;
1	3	3	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
2	3	5	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
3	3	1	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
4	3	7	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
5	3	6	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
6	3	4	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
7	3	2	100.00	10.00	1.00	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659
\.


--
-- Data for Name: contract_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_actions (id, contract_id, action_name, action_description, action_start_date, action_end_date, action_duration_type, action_duration_days, is_active, created_at, updated_at, price_type, adult_age, child_age_range, infant_age_range, adult_price, child_price, infant_price, action_currency, regional_adult_age, regional_child_age, regional_infant_age) FROM stdin;
2	2	test	test	2025-01-01	2025-12-31	day	\N	t	2025-10-28 19:34:17.693101	2025-10-28 19:39:53.626534	fixed	+12	6-11	0-5	100.00	10.00	1.00	USD			
3	2	test2	teset	2025-01-01	2025-12-31	day	\N	t	2025-10-28 19:41:24.409659	2025-10-28 19:41:24.409659	regional				\N	\N	\N	USD	12	3-11	0-2
\.


--
-- Data for Name: contract_kickback_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_kickback_periods (id, contract_id, period_name, start_date, end_date, kickback_type, kickback_value, kickback_currency, kickback_per_person, kickback_min_persons, is_active, created_at, updated_at) FROM stdin;
1	2	test	2025-01-01	2025-12-31	fixed	10.00	USD	t	10	t	2025-10-28 19:23:50.96139	2025-10-28 19:23:50.96139
3	2	test3	2025-01-01	2025-12-31	fixed	10.00	USD	f	100	t	2025-10-28 20:02:06.125429	2025-10-28 20:02:06.125429
2	2	test2	2025-01-01	2025-05-10	percentage	10.00	USD	f	10	t	2025-10-28 19:24:15.874668	2025-10-28 20:13:06.62376
\.


--
-- Data for Name: contract_price_period_regional_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_price_period_regional_prices (id, price_period_id, sub_region_id, adult_price, child_price, infant_price, currency, is_active, created_at, updated_at) FROM stdin;
8	3	3	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
9	3	5	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
10	3	1	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
11	3	7	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
12	3	6	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
13	3	4	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
14	3	2	10.00	10.00	10.00	USD	t	2025-10-28 01:01:21.257227	2025-10-28 01:01:21.257227
22	4	3	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
23	4	5	100.00	10.00	1.01	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
24	4	1	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
25	4	7	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
26	4	6	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
27	4	4	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
28	4	2	100.00	10.00	1.00	USD	t	2025-10-28 22:50:45.63492	2025-10-28 22:50:45.63492
\.


--
-- Data for Name: contract_price_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_price_periods (id, contract_id, period_name, start_date, end_date, days_of_week, adult_price, child_price, infant_price, currency, is_active, notes, created_at, updated_at, price_type, adult_age, child_age_range, infant_age_range) FROM stdin;
2	2	test2	2025-11-06	2025-11-09	monday,thursday,sunday	100.00	10.00	1.00	USD	t	test2	2025-10-28 00:50:13.71655	2025-10-28 00:59:10.415896	fixed	+12	6-11	0-5
3	2	test3	2025-11-10	2025-11-17	monday,wednesday,saturday	\N	\N	\N	USD	t	test3	2025-10-28 00:51:22.114916	2025-10-28 01:01:21.257227	regional	+12	6-11	0-5
1	2	test	2025-10-29	2025-11-03	tuesday,thursday,saturday	100.00	100.00	100.00	USD	t	test	2025-10-28 00:49:37.273573	2025-10-28 01:02:18.066423	fixed	+12	6-11	0-5
4	2	test4	2025-01-01	2025-01-10	monday,thursday,sunday	\N	\N	\N	USD	t	test4	2025-10-28 01:06:15.552359	2025-10-28 22:50:45.63492	regional	+12	6-11	0-5
\.


--
-- Data for Name: contract_regional_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_regional_prices (id, contract_id, sub_region_id, adult_price, adult_currency, child_price, child_currency, infant_price, infant_currency, created_at, updated_at) FROM stdin;
36	2	3	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.517953	2025-10-27 18:24:43.517953
37	2	5	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.518867	2025-10-27 18:24:43.518867
38	2	1	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.519216	2025-10-27 18:24:43.519216
39	2	7	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.51955	2025-10-27 18:24:43.51955
40	2	6	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.519896	2025-10-27 18:24:43.519896
41	2	4	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.520407	2025-10-27 18:24:43.520407
42	2	2	10.00	EUR	10.00	EUR	10.00	EUR	2025-10-27 18:24:43.520819	2025-10-27 18:24:43.520819
\.


--
-- Data for Name: contract_transfer_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_transfer_periods (id, contract_id, period_name, start_date, end_date, transfer_owner, transfer_price_type, transfer_price, transfer_currency, transfer_price_mini, transfer_price_midi, transfer_price_bus, transfer_currency_fixed, is_active, created_at, updated_at, pricing_method, fixed_price_type, adult_age, child_age_range, infant_age_range, adult_price, child_price, infant_price, fixed_currency, group_price, group_currency, regional_adult_age, regional_child_age, regional_infant_age, regional_price_type) FROM stdin;
1	2	test	2025-01-01	2025-12-31	supplier		\N	USD	\N	\N	\N	USD	t	2025-10-28 01:44:47.96256	2025-10-28 01:44:47.96256	fixed_price	per_person	+12	6-11	0-5	100.00	10.00	1.00	USD	\N	USD				
2	2	test2	2025-10-01	2025-12-31	supplier		\N	USD	\N	\N	\N	USD	t	2025-10-28 19:28:12.394791	2025-10-28 19:28:12.394791	fixed_price	per_person	+12	6-11	0-5	100.00	10.00	1.00	USD	\N	USD				
3	2	test4	2025-10-01	2025-12-31	supplier		\N	USD	\N	\N	\N	USD	t	2025-10-28 19:29:07.679997	2025-10-28 19:29:07.679997	fixed_price	group				\N	\N	\N	USD	\N	USD				
4	2	test5	2025-01-01	2025-12-31	supplier		\N	USD	\N	\N	\N	USD	t	2025-10-28 19:30:33.4276	2025-10-29 00:31:32.978477	regional_price					\N	\N	\N	USD	\N	USD	12	3-11	0-2	per_person
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, sub_region_id, merchant_id, tour_id, vat_included, vat_rate, adult_age, child_age_range, infant_age_range, kickback_type, kickback_value, kickback_per_person, kickback_min_persons, included_content, start_date, end_date, created_at, updated_at, price_type, contract_currency, fixed_adult_price, fixed_child_price, fixed_infant_price, kickback_currency, transfer_owner, transfer_price_type, transfer_price, transfer_currency, transfer_price_mini, transfer_price_midi, transfer_price_bus, transfer_currency_fixed, is_active, period_type, period_value, period_unit, tour_departure_days, vehicle_company_id, contract_code) FROM stdin;
3	1	1	4	f	20.00					\N	t	\N	test2	2025-01-01	2025-12-31	2025-10-28 23:33:08.640122	2025-10-28 23:33:08.640122	regional	USD	\N	\N	\N	\N			\N	\N	\N	\N	\N	\N	t	\N	\N	\N		\N	FST-20251028-0001
2	1	1	3	t	\N					\N	t	\N	ALANYA KEMER VE SİDE’DEN; AKSU DOLPHİNARİUM TRANSFER+PAKET PROGRAM (YUNUS + FOK GÖSTERİSİ VE SÜRÜNGENPARK)+YUNUS İLE YÜZME ALAN MİSAFİRLERE PAKET PROGRAM(YUNUS + FOK GÖSTERİSİ VE SÜRÜNGENPARK) ÜCRETSİZDİR.\n	2025-10-27	2025-10-27	2025-10-27 17:56:27.855996	2025-10-29 00:31:36.277127	regional	USD	\N	\N	\N	\N			\N	\N	\N	\N	\N	\N	t	\N	\N	\N		\N	\N
\.


--
-- Data for Name: costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.costs (id, cost_code, cost_name, country_id, region_id, city_id, created_at, updated_at, is_active, valid_from) FROM stdin;
18	FST-00001	Yemek	\N	\N	\N	2025-10-26 22:26:31.569206	2025-10-27 22:53:04.117331	f	2025-10-27
27	FST-00002	Araç	\N	\N	\N	2025-10-28 23:54:56.937274	\N	t	2025-10-28
28	FST-00003	Giriş bileti	\N	\N	\N	2025-10-28 23:56:24.403247	\N	t	2025-10-28
29	FST-00004	Yedek Kaptan	\N	\N	\N	2025-10-28 23:56:32.561336	\N	t	2025-10-28
30	FST-00005	Kokartlı Rehber	\N	\N	\N	2025-10-28 23:56:42.320708	\N	t	2025-10-28
31	FST-00006	Sigorta	\N	\N	\N	2025-10-28 23:56:47.045721	\N	t	2025-10-28
32	FST-00007	Otopark	\N	\N	\N	2025-10-28 23:56:52.442999	\N	t	2025-10-28
33	FST-00008	Rehber Komisyon	\N	\N	\N	2025-10-28 23:57:03.74801	\N	t	2025-10-28
34	FST-00009	Bölge Şefi Komisyonu	\N	\N	\N	2025-10-28 23:57:11.917075	\N	t	2025-10-28
35	FST-00010	Rehber Bonus	\N	\N	\N	2025-10-28 23:58:04.335118	\N	t	2025-10-28
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.countries (id, name, code, created_at, updated_at) FROM stdin;
1	Turkiye	TR	2025-10-26 15:18:17.775421	\N
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currencies (id, code, name, symbol, is_active, created_at, updated_at) FROM stdin;
1	USD	US Dollar	$	t	2025-10-27 16:49:36.636258	2025-10-27 16:49:36.636258
2	EUR	Euro	€	t	2025-10-27 16:49:36.636258	2025-10-27 16:49:36.636258
3	TL	Turkish Lira	₺	t	2025-10-27 16:49:36.636258	2025-10-27 16:49:36.636258
4	GBP	British Pound	£	t	2025-10-27 16:49:36.636258	2025-10-27 16:49:36.636258
5	RUB	Ruble	₽	t	2025-10-28 23:50:42.246401	2025-10-28 23:50:42.246401
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, name, city_id, created_at, updated_at) FROM stdin;
2	Operasyon	1	2025-10-26 17:16:20.412471	\N
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merchants (id, name, official_title, sub_region_id, authorized_person, authorized_email, authorized_phone, operasyon_name, operasyon_email, operasyon_phone, created_at, updated_at, location_url) FROM stdin;
1	Land Of Legends Theme Park	Land Of Legends	1	Test Test	test@test.com	5555555555555	Test Test	test@test.com	5555555555	2025-10-26 16:23:56.172426	2025-10-26 22:58:50.011525	https://www.google.com/maps?q=36.8818763,30.7823927
3	Tazı Kanyon Sun Global	Daban Ogları	2	Test Test	test@test.com	5555555555555	Test Test	test@test.com	5555555555	2025-10-26 22:35:32.907371	2025-10-26 22:59:26.155154	https://maps.app.goo.gl/6g7XepwXLEQsdw4s9
4	Aquarium Antalya	Aquarium Antalya	5	test 1	test@test.com	5855555555555	test 1	test@test.com	5855555555555	2025-10-26 23:55:19.55174	\N	https://www.google.com/maps?q=36.8818763,30.7823927
5	Sena Tour	Aquarium Antalya	3	Test Test	test@test.com	5855555555555	test 1	test@test.com	5855555555555	2025-10-28 23:49:42.317444	\N	https://www.google.com/maps?q=36.8818763,30.7823927
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.positions (id, name, department_id, created_at, updated_at) FROM stdin;
2	Tour Operasyon S1	2	2025-10-26 17:16:43.598174	2025-10-26 22:16:42.99002
3	Tour Operasyon S2	2	2025-10-26 22:16:51.221272	\N
4	Tour Operasyon S3	2	2025-10-26 22:16:58.779762	\N
5	Tour Operasyon S4	2	2025-10-26 22:17:04.758312	\N
6	Tour Operasyon S5	2	2025-10-26 22:17:18.201419	\N
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.regions (id, name, country_id, created_at, updated_at) FROM stdin;
1	Akdeniz	1	2025-10-26 15:18:29.801624	\N
35	Ege	1	2025-10-26 20:38:00.894383	\N
\.


--
-- Data for Name: sub_regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sub_regions (id, name, city_id, created_at, updated_at) FROM stdin;
1	Belek	1	2025-10-26 16:01:56.70299	\N
2	Side	1	2025-10-26 17:21:04.860603	\N
3	Alanya	1	2025-10-26 20:38:30.038802	\N
4	Kemer	1	2025-10-26 20:38:37.638921	\N
5	Antalya	1	2025-10-26 20:38:48.003897	\N
6	Finike	1	2025-10-26 20:38:54.726998	\N
7	Demre	1	2025-10-26 20:39:01.023127	\N
\.


--
-- Data for Name: tour_contract_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tour_contract_routes (id, tour_id, sub_region_id, vehicle_contract_route_id, created_at, updated_at) FROM stdin;
4	4	3	201	2025-10-28 23:56:05.87582	\N
5	4	5	9	2025-10-28 23:56:05.877984	\N
6	4	1	195	2025-10-28 23:56:05.878352	\N
\.


--
-- Data for Name: tour_sub_regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tour_sub_regions (id, tour_id, sub_region_id, created_at) FROM stdin;
5	3	3	2025-10-27 16:56:51.172482
6	3	5	2025-10-27 16:56:51.173319
7	3	1	2025-10-27 16:56:51.173618
8	3	7	2025-10-27 16:56:51.173904
9	3	6	2025-10-27 16:56:51.174189
10	3	4	2025-10-27 16:56:51.174453
11	3	2	2025-10-27 16:56:51.174727
12	4	3	2025-10-27 20:05:09.728846
13	4	5	2025-10-27 20:05:09.729313
14	4	1	2025-10-27 20:05:09.729621
\.


--
-- Data for Name: tours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tours (id, name, sub_region_id, merchant_id, start_date, end_date, created_at, updated_at, sejour_tour_code, vehicle_contract_id) FROM stdin;
3	Land Of Legends Theme Park	1	1	\N	\N	2025-10-26 22:33:54.254521	2025-10-28 20:29:15.317715	LOLPAR	\N
5	Sena Tour	3	5	\N	\N	2025-10-28 23:51:15.339099	\N	SSSSS	\N
4	Caner	1	1	\N	\N	2025-10-27 20:05:09.72663	2025-10-28 23:56:05.799335	CANER	12
\.


--
-- Data for Name: transfer_period_group_ranges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_period_group_ranges (id, transfer_period_id, min_persons, max_persons, price, currency, is_active, created_at, updated_at) FROM stdin;
1	3	1	10	100.00	USD	t	2025-10-28 19:29:07.679997	2025-10-28 19:29:07.679997
2	3	11	25	200.00	USD	t	2025-10-28 19:29:07.679997	2025-10-28 19:29:07.679997
3	3	26	45	300.00	USD	t	2025-10-28 19:29:07.679997	2025-10-28 19:29:07.679997
\.


--
-- Data for Name: transfer_period_regional_group_ranges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_period_regional_group_ranges (id, transfer_period_id, sub_region_id, min_persons, max_persons, price, currency, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transfer_period_regional_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_period_regional_prices (id, transfer_period_id, sub_region_id, adult_price, child_price, infant_price, is_active, created_at, updated_at) FROM stdin;
8	4	3	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
9	4	5	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
10	4	1	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
11	4	7	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
12	4	6	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
13	4	4	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
14	4	2	100.00	10.00	1.00	t	2025-10-29 00:31:32.978477	2025-10-29 00:31:32.978477
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, department_id, city_id, email, phone, status, created_at, updated_at, password_hash) FROM stdin;
2	user.demo	Demo User	2	1	demo@fst.com	+90 555 000 0002	active	2025-10-27 00:18:13.741588	2025-10-27 00:23:34.875804	\N
1	admin	Administrator	2	1	admin@fst.com	+90 555 000 0001	active	2025-10-27 00:18:13.741588	2025-10-27 00:23:57.988783	$2y$12$LNThcMlBbu1/piZje.sequzZ1kMdHjAcsRYdEVcEAh0w/Wz8eeElK
\.


--
-- Data for Name: vehicle_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_companies (id, name, city_id, contact_person, contact_email, contact_phone, created_at, updated_at) FROM stdin;
1	Sena Tour	1	test	test@test.com	555555555555555	2025-10-26 23:31:45.403996	2025-10-26 23:55:57.083642
2	ZemZem	6	test	test@test.com	555555555555555	2025-10-28 23:48:49.501186	\N
\.


--
-- Data for Name: vehicle_contract_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_contract_routes (id, vehicle_contract_id, from_location, to_location, vip_mini_price, mini_price, midi_price, bus_price, price, currency, is_active, created_at, updated_at) FROM stdin;
1	12	ANTALYA	HAVALİMANI	\N	1600.00	2500.00	4100.00	\N	TL	t	2025-10-28 20:55:43.586254	2025-10-28 20:55:43.586254
2	12	KEMER	HAVALİMANI	\N	2600.00	4000.00	6200.00	\N	TL	t	2025-10-28 20:55:43.588869	2025-10-28 20:55:43.588869
3	12	KİRİŞ - ÇAMYUVA-TEKİROVA	HAVALİMANI	\N	2800.00	4280.00	6700.00	\N	TL	t	2025-10-28 20:55:43.589338	2025-10-28 20:55:43.589338
4	12	BELEK	HAVALİMANI	\N	2270.00	3500.00	5600.00	\N	TL	t	2025-10-28 20:55:43.58987	2025-10-28 20:55:43.58987
5	12	BOĞAZKENT	HAVALİMANI	\N	2450.00	3850.00	6000.00	\N	TL	t	2025-10-28 20:55:43.590258	2025-10-28 20:55:43.590258
6	12	DENİZYAKA LİKYA WORLD	HAVALİMANI	\N	2750.00	4100.00	6900.00	\N	TL	t	2025-10-28 20:55:43.590746	2025-10-28 20:55:43.590746
7	12	SİDE	HAVALİMANI	\N	2750.00	4100.00	6900.00	\N	TL	t	2025-10-28 20:55:43.591248	2025-10-28 20:55:43.591248
8	12	KIZILAĞAÇ - KIZILOT	HAVALİMANI	\N	2940.00	4350.00	7300.00	\N	TL	t	2025-10-28 20:55:43.591732	2025-10-28 20:55:43.591732
9	12	ALANYA	HAVALİMANI	\N	3640.00	5500.00	8665.00	\N	TL	t	2025-10-28 20:55:43.592394	2025-10-28 20:55:43.592394
10	12	MAHMUTLAR	HAVALİMANI	\N	3825.00	5775.00	9100.00	\N	TL	t	2025-10-28 20:55:43.592752	2025-10-28 20:55:43.592752
11	12	ÇIRALI	HAVALİMANI	\N	3470.00	5400.00	8920.00	\N	TL	t	2025-10-28 20:55:43.593236	2025-10-28 20:55:43.593236
12	12	ADRASAN	HAVALİMANI	\N	3840.00	5795.00	9640.00	\N	TL	t	2025-10-28 20:55:43.593713	2025-10-28 20:55:43.593713
13	12	KUMLUCA	HAVALİMANI	\N	4205.00	6360.00	10270.00	\N	TL	t	2025-10-28 20:55:43.594214	2025-10-28 20:55:43.594214
14	12	FİNİKE	HAVALİMANI	\N	4885.00	7380.00	11445.00	\N	TL	t	2025-10-28 20:55:43.594544	2025-10-28 20:55:43.594544
15	12	DEMRE	HAVALİMANI	\N	6235.00	9430.00	15285.00	\N	TL	t	2025-10-28 20:55:43.594876	2025-10-28 20:55:43.594876
16	12	KAŞ	HAVALİMANI	\N	7440.00	11720.00	19775.00	\N	TL	t	2025-10-28 20:55:43.595198	2025-10-28 20:55:43.595198
17	12	FETHİYE	HAVALİMANI	\N	8205.00	13210.00	22220.00	\N	TL	t	2025-10-28 20:55:43.595526	2025-10-28 20:55:43.595526
18	12	DALAMAN	HAVALİMANI	\N	9160.00	14665.00	24685.00	\N	TL	t	2025-10-28 20:55:43.595856	2025-10-28 20:55:43.595856
19	12	MARMARİS	HAVALİMANI	\N	12790.00	20550.00	34595.00	\N	TL	t	2025-10-28 20:55:43.596184	2025-10-28 20:55:43.596184
20	12	BODRUM	HAVALİMANI	\N	16455.00	26410.00	44475.00	\N	TL	t	2025-10-28 20:55:43.596507	2025-10-28 20:55:43.596507
21	12	GAZİPAŞA	ALANYA	\N	3120.00	4800.00	8000.00	\N	TL	t	2025-10-28 20:55:43.596841	2025-10-28 20:55:43.596841
22	12	GAZİPAŞA	SİDE	\N	3880.00	6050.00	10100.00	\N	TL	t	2025-10-28 20:55:43.597166	2025-10-28 20:55:43.597166
23	12	GAZİPAŞA	BELEK	\N	4600.00	7200.00	12100.00	\N	TL	t	2025-10-28 20:55:43.597496	2025-10-28 20:55:43.597496
24	12	GAZİPAŞA	ANTALYA	\N	5350.00	8450.00	14100.00	\N	TL	t	2025-10-28 20:55:43.597822	2025-10-28 20:55:43.597822
25	12	GAZİPAŞA	KEMER	\N	6550.00	10300.00	17250.00	\N	TL	t	2025-10-28 20:55:43.598161	2025-10-28 20:55:43.598161
26	12	MANAVGAT BOT TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.598486	2025-10-28 20:55:43.598486
27	12	MANAVGAT BOT TURU	KEMER	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 20:55:43.598811	2025-10-28 20:55:43.598811
28	12	MANAVGAT BOT TURU	BELEK	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 20:55:43.599138	2025-10-28 20:55:43.599138
29	12	MANAVGAT BOT TURU	SİDE	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 20:55:43.59946	2025-10-28 20:55:43.59946
30	12	MANAVGAT BOT TURU	ALANYA	\N	6030.00	8695.00	13220.00	\N	TL	t	2025-10-28 20:55:43.599783	2025-10-28 20:55:43.599783
31	12	DISCOVERY PARK TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.60016	2025-10-28 20:55:43.60016
32	12	DISCOVERY PARK TURU	KEMER	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 20:55:43.600499	2025-10-28 20:55:43.600499
33	12	DISCOVERY PARK TURU	BELEK	\N	4380.00	6940.00	10780.00	\N	TL	t	2025-10-28 20:55:43.600826	2025-10-28 20:55:43.600826
34	12	DISCOVERY PARK TURU	SİDE	\N	3880.00	5540.00	8400.00	\N	TL	t	2025-10-28 20:55:43.601149	2025-10-28 20:55:43.601149
35	12	DISCOVERY PARK TURU	ALANYA	\N	5030.00	7330.00	11175.00	\N	TL	t	2025-10-28 20:55:43.601473	2025-10-28 20:55:43.601473
36	12	BELEK LAND OF LEGENDS TURU	ANTALYA	\N	5360.00	7590.00	11480.00	\N	TL	t	2025-10-28 20:55:43.601796	2025-10-28 20:55:43.601796
37	12	BELEK LAND OF LEGENDS TURU	KEMER	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.602118	2025-10-28 20:55:43.602118
38	12	BELEK LAND OF LEGENDS TURU	BELEK	\N	4815.00	6935.00	10735.00	\N	TL	t	2025-10-28 20:55:43.602546	2025-10-28 20:55:43.602546
39	12	BELEK LAND OF LEGENDS TURU	SİDE	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 20:55:43.602943	2025-10-28 20:55:43.602943
40	12	BELEK LAND OF LEGENDS TURU	ALANYA	\N	6425.00	9430.00	14375.00	\N	TL	t	2025-10-28 20:55:43.603333	2025-10-28 20:55:43.603333
41	12	AQUALAND TURU / AKVARYUM TURU	ANTALYA	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 20:55:43.603761	2025-10-28 20:55:43.603761
42	12	AQUALAND TURU / AKVARYUM TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 20:55:43.604154	2025-10-28 20:55:43.604154
43	12	AQUALAND TURU / AKVARYUM TURU	BELEK	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 20:55:43.60451	2025-10-28 20:55:43.60451
44	12	AQUALAND TURU / AKVARYUM TURU	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.604835	2025-10-28 20:55:43.604835
45	12	AQUALAND TURU / AKVARYUM TURU	ALANYA	\N	6815.00	10155.00	15530.00	\N	TL	t	2025-10-28 20:55:43.605186	2025-10-28 20:55:43.605186
46	12	TÜNEKTEPE TELEFERİK TURU	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 20:55:43.60551	2025-10-28 20:55:43.60551
47	12	TÜNEKTEPE TELEFERİK TURU	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 20:55:43.605894	2025-10-28 20:55:43.605894
48	12	TÜNEKTEPE TELEFERİK TURU	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.606497	2025-10-28 20:55:43.606497
49	12	TÜNEKTEPE TELEFERİK TURU	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.606941	2025-10-28 20:55:43.606941
50	12	TÜNEKTEPE TELEFERİK TURU	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 20:55:43.607286	2025-10-28 20:55:43.607286
51	12	ANTALYA YAT TURU SETUR MARİNA	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 20:55:43.607613	2025-10-28 20:55:43.607613
52	12	ANTALYA YAT TURU SETUR MARİNA	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 20:55:43.607941	2025-10-28 20:55:43.607941
53	12	ANTALYA YAT TURU SETUR MARİNA	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.608303	2025-10-28 20:55:43.608303
54	12	ANTALYA YAT TURU SETUR MARİNA	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.608642	2025-10-28 20:55:43.608642
55	12	ANTALYA YAT TURU SETUR MARİNA	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 20:55:43.608967	2025-10-28 20:55:43.608967
56	12	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 20:55:43.609297	2025-10-28 20:55:43.609297
57	12	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 20:55:43.609628	2025-10-28 20:55:43.609628
58	12	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.609953	2025-10-28 20:55:43.609953
59	12	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	SİDE	\N	6120.00	8980.00	13690.00	\N	TL	t	2025-10-28 20:55:43.610279	2025-10-28 20:55:43.610279
60	12	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 20:55:43.610624	2025-10-28 20:55:43.610624
61	12	ANTALYA ŞEHİR TURU	ANTALYA	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 20:55:43.61095	2025-10-28 20:55:43.61095
62	12	ANTALYA ŞEHİR TURU	KEMER	\N	5785.00	8710.00	13565.00	\N	TL	t	2025-10-28 20:55:43.611277	2025-10-28 20:55:43.611277
63	12	ANTALYA ŞEHİR TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 20:55:43.611602	2025-10-28 20:55:43.611602
64	12	ANTALYA ŞEHİR TURU	SİDE	\N	6220.00	9170.00	14000.00	\N	TL	t	2025-10-28 20:55:43.611933	2025-10-28 20:55:43.611933
65	12	ANTALYA ŞEHİR TURU	ALANYA	\N	7275.00	10985.00	16855.00	\N	TL	t	2025-10-28 20:55:43.612275	2025-10-28 20:55:43.612275
66	12	ALANYA ŞEHİR TURU	SİDE	\N	5950.00	8680.00	13220.00	\N	TL	t	2025-10-28 20:55:43.612601	2025-10-28 20:55:43.612601
67	12	ALANYA ŞEHİR TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 20:55:43.612928	2025-10-28 20:55:43.612928
68	12	ALARAHAN PİKNİK TURU	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.613253	2025-10-28 20:55:43.613253
69	12	ALARAHAN PİKNİK TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 20:55:43.613578	2025-10-28 20:55:43.613578
70	12	ALANYA BOT TURU	SİDE	\N	5670.00	8495.00	13225.00	\N	TL	t	2025-10-28 20:55:43.613909	2025-10-28 20:55:43.613909
71	12	ALANYA BOT TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 20:55:43.614235	2025-10-28 20:55:43.614235
72	12	WATER PLANET	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.614581	2025-10-28 20:55:43.614581
73	12	WATER PLANET	ALANYA	\N	5745.00	8180.00	12390.00	\N	TL	t	2025-10-28 20:55:43.614912	2025-10-28 20:55:43.614912
74	12	SEA ALANYA DOLPHIN TURU	ANTALYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.615891	2025-10-28 20:55:43.615891
75	12	SEA ALANYA DOLPHIN TURU	KEMER	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 20:55:43.616227	2025-10-28 20:55:43.616227
76	12	SEA ALANYA DOLPHIN TURU	BELEK	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.616558	2025-10-28 20:55:43.616558
77	12	SEA ALANYA DOLPHIN TURU	SİDE	\N	4890.00	7180.00	10950.00	\N	TL	t	2025-10-28 20:55:43.616889	2025-10-28 20:55:43.616889
78	12	SEA ALANYA DOLPHIN TURU	ALANYA	\N	4360.00	6345.00	9650.00	\N	TL	t	2025-10-28 20:55:43.617218	2025-10-28 20:55:43.617218
79	12	SEA ALANYA TAM GÜN	ANTALYA	\N	6390.00	9470.00	14480.00	\N	TL	t	2025-10-28 20:55:43.617547	2025-10-28 20:55:43.617547
80	12	SEA ALANYA TAM GÜN	KEMER	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 20:55:43.61788	2025-10-28 20:55:43.61788
81	12	SEA ALANYA TAM GÜN	BELEK	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.618225	2025-10-28 20:55:43.618225
82	12	SEA ALANYA TAM GÜN	SİDE	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 20:55:43.618558	2025-10-28 20:55:43.618558
83	12	SEA ALANYA TAM GÜN	ALANYA	\N	5860.00	8390.00	12715.00	\N	TL	t	2025-10-28 20:55:43.618915	2025-10-28 20:55:43.618915
84	12	SİDE ŞEHİR TURU	SİDE	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 20:55:43.619405	2025-10-28 20:55:43.619405
85	12	SİDE ŞEHİR TURU	ALANYA	\N	6250.00	9115.00	13880.00	\N	TL	t	2025-10-28 20:55:43.619852	2025-10-28 20:55:43.619852
86	12	BEŞKONAK TURU	ANTALYA	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.620269	2025-10-28 20:55:43.621495
87	12	BEŞKONAK TURU	KEMER	\N	6435.00	9900.00	15455.00	\N	TL	t	2025-10-28 20:55:43.620712	2025-10-28 20:55:43.622053
88	12	BEŞKONAK TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 20:55:43.621094	2025-10-28 20:55:43.622408
89	12	BEŞKONAK TURU	SİDE	\N	6060.00	8880.00	13530.00	\N	TL	t	2025-10-28 20:55:43.622756	2025-10-28 20:55:43.622756
90	12	BEŞKONAK TURU	ALANYA	\N	6880.00	10260.00	15700.00	\N	TL	t	2025-10-28 20:55:43.623091	2025-10-28 20:55:43.623091
91	12	TAZI KANYONU TURU	ANTALYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.623427	2025-10-28 20:55:43.623427
92	12	TAZI KANYONU TURU	KEMER	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.623761	2025-10-28 20:55:43.623761
93	12	TAZI KANYONU TURU	BELEK	\N	5490.00	8175.00	12710.00	\N	TL	t	2025-10-28 20:55:43.624094	2025-10-28 20:55:43.624094
94	12	TAZI KANYONU TURU	SİDE	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.624426	2025-10-28 20:55:43.624426
95	12	TAZI KANYONU TURU	ALANYA	\N	7160.00	10775.00	16530.00	\N	TL	t	2025-10-28 20:55:43.624757	2025-10-28 20:55:43.624757
96	12	ASPENDOS KONSER TURU	ANTALYA	\N	4090.00	5940.00	9030.00	\N	TL	t	2025-10-28 20:55:43.625089	2025-10-28 20:55:43.625089
97	12	ASPENDOS KONSER TURU	KEMER	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.62542	2025-10-28 20:55:43.62542
98	12	ASPENDOS KONSER TURU	BELEK	\N	2660.00	3925.00	6095.00	\N	TL	t	2025-10-28 20:55:43.625755	2025-10-28 20:55:43.625755
99	12	ASPENDOS KONSER TURU	SİDE	\N	3980.00	5740.00	8720.00	\N	TL	t	2025-10-28 20:55:43.626088	2025-10-28 20:55:43.626088
100	12	ASPENDOS KONSER TURU	ALANYA	\N	6365.00	9325.00	14205.00	\N	TL	t	2025-10-28 20:55:43.626419	2025-10-28 20:55:43.626419
101	12	OYMAPINAR PİKNİK TURU	ANTALYA	\N	5950.00	8680.00	13225.00	\N	TL	t	2025-10-28 20:55:43.626752	2025-10-28 20:55:43.626752
102	12	OYMAPINAR PİKNİK TURU	KEMER	\N	6435.00	9900.00	15455.00	\N	TL	t	2025-10-28 20:55:43.627087	2025-10-28 20:55:43.627087
103	12	OYMAPINAR PİKNİK TURU	BELEK	\N	5375.00	7960.00	12365.00	\N	TL	t	2025-10-28 20:55:43.62742	2025-10-28 20:55:43.62742
104	12	OYMAPINAR PİKNİK TURU	SİDE	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 20:55:43.627755	2025-10-28 20:55:43.627755
105	12	OYMAPINAR PİKNİK TURU	ALANYA	\N	6250.00	9115.00	13880.00	\N	TL	t	2025-10-28 20:55:43.628133	2025-10-28 20:55:43.628133
106	12	KARACAÖREN PİKNİK TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 20:55:43.628497	2025-10-28 20:55:43.628497
107	12	KARACAÖREN PİKNİK TURU	KEMER	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.628831	2025-10-28 20:55:43.628831
108	12	KARACAÖREN PİKNİK TURU	BELEK	\N	5610.00	8390.00	13050.00	\N	TL	t	2025-10-28 20:55:43.629175	2025-10-28 20:55:43.629175
109	12	KARACAÖREN PİKNİK TURU	SİDE	\N	6080.00	9250.00	14425.00	\N	TL	t	2025-10-28 20:55:43.629508	2025-10-28 20:55:43.629508
110	12	KARACAÖREN PİKNİK TURU	ALANYA	\N	7275.00	10985.00	16855.00	\N	TL	t	2025-10-28 20:55:43.629844	2025-10-28 20:55:43.629844
111	12	DEMRE KEKOVA TURU	ANTALYA	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.630178	2025-10-28 20:55:43.630178
112	12	DEMRE KEKOVA TURU	KEMER	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.630515	2025-10-28 20:55:43.630515
113	12	DEMRE KEKOVA TURU	BELEK	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 20:55:43.630848	2025-10-28 20:55:43.630848
114	12	DEMRE KEKOVA TURU	SİDE	\N	7435.00	11730.00	18370.00	\N	TL	t	2025-10-28 20:55:43.631182	2025-10-28 20:55:43.631182
115	12	DEMRE KEKOVA TURU	ALANYA	\N	8695.00	13590.00	21000.00	\N	TL	t	2025-10-28 20:55:43.631517	2025-10-28 20:55:43.631517
116	12	PAMUKKALE 1 GÜN	ANTALYA	\N	8500.00	13000.00	21500.00	\N	TL	t	2025-10-28 20:55:43.631847	2025-10-28 20:55:43.631847
117	12	PAMUKKALE 1 GÜN	KEMER	\N	9190.00	14065.00	23345.00	\N	TL	t	2025-10-28 20:55:43.63218	2025-10-28 20:55:43.63218
118	12	PAMUKKALE 1 GÜN	BELEK	\N	9190.00	14065.00	23345.00	\N	TL	t	2025-10-28 20:55:43.632516	2025-10-28 20:55:43.632516
119	12	PAMUKKALE 1 GÜN	SİDE	\N	8490.00	13670.00	21455.00	\N	TL	t	2025-10-28 20:55:43.63285	2025-10-28 20:55:43.63285
120	12	PAMUKKALE 1 GÜN	ALANYA	\N	9255.00	15070.00	23685.00	\N	TL	t	2025-10-28 20:55:43.633186	2025-10-28 20:55:43.633186
121	12	PAMUKKALE SALDA TURU	ANTALYA	\N	9500.00	15000.00	24750.00	\N	TL	t	2025-10-28 20:55:43.633524	2025-10-28 20:55:43.633524
122	12	PAMUKKALE SALDA TURU	KEMER	\N	10315.00	15940.00	25780.00	\N	TL	t	2025-10-28 20:55:43.633855	2025-10-28 20:55:43.633855
123	12	PAMUKKALE SALDA TURU	BELEK	\N	10315.00	15940.00	25780.00	\N	TL	t	2025-10-28 20:55:43.634191	2025-10-28 20:55:43.634191
124	12	PAMUKKALE SALDA TURU	SİDE	\N	8785.00	14210.00	22315.00	\N	TL	t	2025-10-28 20:55:43.634527	2025-10-28 20:55:43.634527
125	12	PAMUKKALE SALDA TURU	ALANYA	\N	9550.00	15610.00	24540.00	\N	TL	t	2025-10-28 20:55:43.63486	2025-10-28 20:55:43.63486
126	12	PAMUKKALE 2 GÜN	ANTALYA	\N	12570.00	19255.00	30050.00	\N	TL	t	2025-10-28 20:55:43.635196	2025-10-28 20:55:43.635196
127	12	PAMUKKALE 2 GÜN	KEMER	\N	13040.00	20120.00	31420.00	\N	TL	t	2025-10-28 20:55:43.63557	2025-10-28 20:55:43.63557
128	12	PAMUKKALE 2 GÜN	BELEK	\N	12690.00	19475.00	30390.00	\N	TL	t	2025-10-28 20:55:43.63603	2025-10-28 20:55:43.63603
129	12	PAMUKKALE 2 GÜN	SİDE	\N	13280.00	20550.00	32105.00	\N	TL	t	2025-10-28 20:55:43.636436	2025-10-28 20:55:43.636436
130	12	PAMUKKALE 2 GÜN	ALANYA	\N	15110.00	23005.00	35365.00	\N	TL	t	2025-10-28 20:55:43.636798	2025-10-28 20:55:43.636798
131	12	KAPADOKYA 2 GÜN	ANTALYA	\N	19000.00	29000.00	46000.00	\N	TL	t	2025-10-28 20:55:43.637159	2025-10-28 20:55:43.637159
132	12	KAPADOKYA 2 GÜN	KEMER	\N	17215.00	27775.00	43595.00	\N	TL	t	2025-10-28 20:55:43.637612	2025-10-28 20:55:43.637612
133	12	KAPADOKYA 2 GÜN	BELEK	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 20:55:43.638006	2025-10-28 20:55:43.638006
134	12	KAPADOKYA 2 GÜN	SİDE	\N	15805.00	25185.00	39480.00	\N	TL	t	2025-10-28 20:55:43.638419	2025-10-28 20:55:43.638419
135	12	KAPADOKYA 2 GÜN	ALANYA	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 20:55:43.638799	2025-10-28 20:55:43.638799
136	12	EFES PAMUKKALE 2 GÜN	ANTALYA	\N	18000.00	27000.00	45000.00	\N	TL	t	2025-10-28 20:55:43.63917	2025-10-28 20:55:43.63917
137	12	EFES PAMUKKALE 2 GÜN	KEMER	\N	18750.00	28125.00	48750.00	\N	TL	t	2025-10-28 20:55:43.639509	2025-10-28 20:55:43.639509
138	12	EFES PAMUKKALE 2 GÜN	BELEK	\N	17815.00	26250.00	44065.00	\N	TL	t	2025-10-28 20:55:43.639878	2025-10-28 20:55:43.639878
139	12	EFES PAMUKKALE 2 GÜN	SİDE	\N	16980.00	27340.00	42910.00	\N	TL	t	2025-10-28 20:55:43.640223	2025-10-28 20:55:43.640223
140	12	EFES PAMUKKALE 2 GÜN	ALANYA	\N	19080.00	30285.00	46935.00	\N	TL	t	2025-10-28 20:55:43.640562	2025-10-28 20:55:43.640562
141	12	DEMRE PAMUKKALE TURU 2 GÜN	ANTALYA	\N	16000.00	21910.00	39000.00	\N	TL	t	2025-10-28 20:55:43.640904	2025-10-28 20:55:43.640904
142	12	DEMRE PAMUKKALE TURU 2 GÜN	KEMER	\N	15220.00	24110.00	37765.00	\N	TL	t	2025-10-28 20:55:43.641243	2025-10-28 20:55:43.641243
143	12	DEMRE PAMUKKALE TURU 2 GÜN	BELEK	\N	14630.00	23030.00	36050.00	\N	TL	t	2025-10-28 20:55:43.641581	2025-10-28 20:55:43.641581
144	12	DEMRE PAMUKKALE TURU 2 GÜN	SİDE	\N	15220.00	24110.00	37765.00	\N	TL	t	2025-10-28 20:55:43.641923	2025-10-28 20:55:43.641923
145	12	DEMRE PAMUKKALE TURU 2 GÜN	ALANYA	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 20:55:43.642262	2025-10-28 20:55:43.642262
146	12	KAŞ TURU	ANTALYA	\N	7610.00	12055.00	18885.00	\N	TL	t	2025-10-28 20:55:43.642643	2025-10-28 20:55:43.642643
147	12	KAŞ TURU	KEMER	\N	6550.00	10115.00	15795.00	\N	TL	t	2025-10-28 20:55:43.642982	2025-10-28 20:55:43.642982
148	12	KEMER ŞEHİR TURU	ANTALYA	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 20:55:43.643321	2025-10-28 20:55:43.643321
149	12	KEMER ŞEHİR TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 20:55:43.64366	2025-10-28 20:55:43.64366
150	12	KEMER ŞEHİR TURU	BELEK	\N	6200.00	9465.00	14765.00	\N	TL	t	2025-10-28 20:55:43.643999	2025-10-28 20:55:43.643999
151	12	KEMER ŞEHİR TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.644338	2025-10-28 20:55:43.644338
152	12	KEMER ŞEHİR TURU	ALANYA	\N	8010.00	12340.00	19005.00	\N	TL	t	2025-10-28 20:55:43.644679	2025-10-28 20:55:43.644679
153	12	ADRASAN SULUADA TURU	ANTALYA	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 20:55:43.645032	2025-10-28 20:55:43.645032
154	12	ADRASAN SULUADA TURU	KEMER	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.645371	2025-10-28 20:55:43.645371
155	12	ADRASAN SULUADA TURU	BELEK	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 20:55:43.645711	2025-10-28 20:55:43.645711
156	12	ADRASAN SULUADA TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.646056	2025-10-28 20:55:43.646056
157	12	ADRASAN SULUADA TURU	ALANYA	\N	8130.00	12550.00	19330.00	\N	TL	t	2025-10-28 20:55:43.646395	2025-10-28 20:55:43.646395
158	12	KEMER BOT TURU	ANTALYA	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.646736	2025-10-28 20:55:43.646736
159	12	KEMER BOT TURU	KEMER	\N	4965.00	7205.00	11165.00	\N	TL	t	2025-10-28 20:55:43.647077	2025-10-28 20:55:43.647077
160	12	KEMER BOT TURU	BELEK	\N	5725.00	8605.00	13395.00	\N	TL	t	2025-10-28 20:55:43.64742	2025-10-28 20:55:43.64742
161	12	KEMER BOT TURU	SİDE	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.647764	2025-10-28 20:55:43.647764
162	12	KEMER BOT TURU	ALANYA	\N	7560.00	11510.00	17685.00	\N	TL	t	2025-10-28 20:55:43.648119	2025-10-28 20:55:43.648119
163	12	GÖYNÜK DİNOPARK TURU	ANTALYA	\N	5630.00	8080.00	12270.00	\N	TL	t	2025-10-28 20:55:43.648491	2025-10-28 20:55:43.648491
164	12	GÖYNÜK DİNOPARK TURU	KEMER	\N	4965.00	7205.00	11165.00	\N	TL	t	2025-10-28 20:55:43.648839	2025-10-28 20:55:43.648839
165	12	GÖYNÜK DİNOPARK TURU	BELEK	\N	5610.00	8390.00	13050.00	\N	TL	t	2025-10-28 20:55:43.649187	2025-10-28 20:55:43.649187
166	12	TAHTALI TURU	ANTALYA	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.649529	2025-10-28 20:55:43.649529
167	12	TAHTALI TURU	KEMER	\N	5080.00	7420.00	11510.00	\N	TL	t	2025-10-28 20:55:43.649873	2025-10-28 20:55:43.649873
168	12	TAHTALI TURU	BELEK	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 20:55:43.650287	2025-10-28 20:55:43.650287
169	12	TAHTALI TURU	SİDE	\N	6490.00	10005.00	15625.00	\N	TL	t	2025-10-28 20:55:43.650638	2025-10-28 20:55:43.650638
170	12	TAHTALI TURU	ALANYA	\N	7780.00	11920.00	18345.00	\N	TL	t	2025-10-28 20:55:43.650982	2025-10-28 20:55:43.650982
171	12	TAHTALI + AKVARYUM TURU	ANTALYA	\N	6120.00	9500.00	15000.00	\N	TL	t	2025-10-28 20:55:43.651348	2025-10-28 20:55:43.651348
172	12	TAHTALI + AKVARYUM TURU	KEMER	\N	5670.00	8495.00	13225.00	\N	TL	t	2025-10-28 20:55:43.651713	2025-10-28 20:55:43.651713
173	12	TAHTALI + AKVARYUM TURU	BELEK	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 20:55:43.652081	2025-10-28 20:55:43.652081
174	12	TAHTALI + AKVARYUM TURU	SİDE	\N	6490.00	10005.00	15625.00	\N	TL	t	2025-10-28 20:55:43.652517	2025-10-28 20:55:43.652517
175	12	TAHTALI + AKVARYUM TURU	ALANYA	\N	7780.00	11920.00	18345.00	\N	TL	t	2025-10-28 20:55:43.652891	2025-10-28 20:55:43.652891
176	12	ULUPINAR OLİMPOS PHASELİS TURU	ANTALYA	\N	6280.00	9270.00	14160.00	\N	TL	t	2025-10-28 20:55:43.653269	2025-10-28 20:55:43.653269
177	12	ULUPINAR OLİMPOS PHASELİS TURU	KEMER	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.653697	2025-10-28 20:55:43.653697
178	12	ULUPINAR OLİMPOS PHASELİS TURU	BELEK	\N	6200.00	9465.00	14765.00	\N	TL	t	2025-10-28 20:55:43.654091	2025-10-28 20:55:43.654091
179	12	ULUPINAR OLİMPOS PHASELİS TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.654455	2025-10-28 20:55:43.654455
180	12	ULUPINAR OLİMPOS PHASELİS TURU	ALANYA	\N	8010.00	12340.00	19005.00	\N	TL	t	2025-10-28 20:55:43.654806	2025-10-28 20:55:43.654806
181	12	PERGE ANTALYA TURU	ANTALYA	\N	5630.00	8080.00	12270.00	\N	TL	t	2025-10-28 20:55:43.655154	2025-10-28 20:55:43.655154
182	12	PERGE ANTALYA TURU	KEMER	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 20:55:43.655503	2025-10-28 20:55:43.655503
183	12	PERGE ANTALYA TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 20:55:43.655855	2025-10-28 20:55:43.655855
184	12	PERGE ANTALYA TURU	SİDE	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 20:55:43.656203	2025-10-28 20:55:43.656203
185	12	PERGE ANTALYA TURU	ALANYA	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 20:55:43.656548	2025-10-28 20:55:43.656548
186	12	PERGE ASPENDOS SİDE	ANTALYA	\N	5725.00	8605.00	13395.00	\N	TL	t	2025-10-28 20:55:43.656899	2025-10-28 20:55:43.656899
187	12	PERGE ASPENDOS SİDE	KEMER	\N	6375.00	9790.00	15280.00	\N	TL	t	2025-10-28 20:55:43.65727	2025-10-28 20:55:43.65727
188	12	PERGE ASPENDOS SİDE	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 20:55:43.657636	2025-10-28 20:55:43.657636
189	12	PERGE ASPENDOS SİDE	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 20:55:43.658076	2025-10-28 20:55:43.658076
190	12	PERGE ASPENDOS SİDE	ALANYA	\N	6670.00	10330.00	16140.00	\N	TL	t	2025-10-28 20:55:43.658674	2025-10-28 20:55:43.658674
191	12	ANTALYA AKŞAM YEMEK TURU	ANTALYA	\N	3970.00	5760.00	8930.00	\N	TL	t	2025-10-28 20:55:43.659111	2025-10-28 20:55:43.659111
192	12	ANTALYA AKŞAM YEMEK TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 20:55:43.659509	2025-10-28 20:55:43.659509
193	12	ANTALYA AKŞAM YEMEK TURU	BELEK	\N	4205.00	6195.00	9620.00	\N	TL	t	2025-10-28 20:55:43.65989	2025-10-28 20:55:43.65989
194	12	ANTALYA AKŞAM YEMEK TURU	SİDE	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 20:55:43.660251	2025-10-28 20:55:43.660251
195	12	ANTALYA AKŞAM YEMEK TURU	ALANYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 20:55:43.660726	2025-10-28 20:55:43.660726
196	12	KEMER	KEMER	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 20:55:43.66115	2025-10-28 20:55:43.66115
197	12	KEMER	ANTALYA	\N	2510.00	3895.00	5950.00	\N	TL	t	2025-10-28 20:55:43.661532	2025-10-28 20:55:43.661532
198	12	KEMER	BELEK	\N	4150.00	6470.00	9890.00	\N	TL	t	2025-10-28 20:55:43.661894	2025-10-28 20:55:43.661894
199	12	KEMER	SİDE	\N	5480.00	8665.00	13375.00	\N	TL	t	2025-10-28 20:55:43.662263	2025-10-28 20:55:43.662263
200	12	KEMER	ALANYA	\N	7570.00	12085.00	18610.00	\N	TL	t	2025-10-28 20:55:43.662613	2025-10-28 20:55:43.662613
201	12	ANTALYA	ANTALYA	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 20:55:43.662962	2025-10-28 20:55:43.662962
202	12	ANTALYA	BELEK	\N	2160.00	3275.00	4915.00	\N	TL	t	2025-10-28 20:55:43.663309	2025-10-28 20:55:43.663309
203	12	ANTALYA	SİDE	\N	3115.00	4870.00	7360.00	\N	TL	t	2025-10-28 20:55:43.663655	2025-10-28 20:55:43.663655
204	12	ANTALYA	ALANYA	\N	4355.00	6865.00	10565.00	\N	TL	t	2025-10-28 20:55:43.664006	2025-10-28 20:55:43.664006
205	12	BELEK	BELEK	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 20:55:43.664355	2025-10-28 20:55:43.664355
206	12	BELEK	SİDE	\N	2420.00	3700.00	5650.00	\N	TL	t	2025-10-28 20:55:43.664724	2025-10-28 20:55:43.664724
207	12	BELEK	ALANYA	\N	3985.00	6255.00	9505.00	\N	TL	t	2025-10-28 20:55:43.665073	2025-10-28 20:55:43.665073
208	12	SİDE	SİDE	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 20:55:43.665423	2025-10-28 20:55:43.665423
209	12	SİDE	ALANYA	\N	3115.00	4870.00	7360.00	\N	TL	t	2025-10-28 20:55:43.665768	2025-10-28 20:55:43.665768
210	12	BÖLGE İÇİ ARA TRANSFER	ARA TRANSFER	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 20:55:43.666142	2025-10-28 20:55:43.666142
211	13	ANTALYA	HAVALİMANI	\N	1600.00	2500.00	4100.00	\N	TL	t	2025-10-28 23:49:23.064051	2025-10-28 23:49:23.064051
212	13	KEMER	HAVALİMANI	\N	2600.00	4000.00	6200.00	\N	TL	t	2025-10-28 23:49:23.071256	2025-10-28 23:49:23.071256
213	13	KİRİŞ - ÇAMYUVA-TEKİROVA	HAVALİMANI	\N	2800.00	4280.00	6700.00	\N	TL	t	2025-10-28 23:49:23.072102	2025-10-28 23:49:23.072102
214	13	BELEK	HAVALİMANI	\N	2270.00	3500.00	5600.00	\N	TL	t	2025-10-28 23:49:23.072841	2025-10-28 23:49:23.072841
215	13	BOĞAZKENT	HAVALİMANI	\N	2450.00	3850.00	6000.00	\N	TL	t	2025-10-28 23:49:23.073448	2025-10-28 23:49:23.073448
216	13	DENİZYAKA LİKYA WORLD	HAVALİMANI	\N	2750.00	4100.00	6900.00	\N	TL	t	2025-10-28 23:49:23.073978	2025-10-28 23:49:23.073978
217	13	SİDE	HAVALİMANI	\N	2750.00	4100.00	6900.00	\N	TL	t	2025-10-28 23:49:23.074378	2025-10-28 23:49:23.074378
218	13	KIZILAĞAÇ - KIZILOT	HAVALİMANI	\N	2940.00	4350.00	7300.00	\N	TL	t	2025-10-28 23:49:23.074713	2025-10-28 23:49:23.074713
219	13	ALANYA	HAVALİMANI	\N	3640.00	5500.00	8665.00	\N	TL	t	2025-10-28 23:49:23.075052	2025-10-28 23:49:23.075052
220	13	MAHMUTLAR	HAVALİMANI	\N	3825.00	5775.00	9100.00	\N	TL	t	2025-10-28 23:49:23.075576	2025-10-28 23:49:23.075576
221	13	ÇIRALI	HAVALİMANI	\N	3470.00	5400.00	8920.00	\N	TL	t	2025-10-28 23:49:23.075915	2025-10-28 23:49:23.075915
222	13	ADRASAN	HAVALİMANI	\N	3840.00	5795.00	9640.00	\N	TL	t	2025-10-28 23:49:23.076245	2025-10-28 23:49:23.076245
223	13	KUMLUCA	HAVALİMANI	\N	4205.00	6360.00	10270.00	\N	TL	t	2025-10-28 23:49:23.076575	2025-10-28 23:49:23.076575
224	13	FİNİKE	HAVALİMANI	\N	4885.00	7380.00	11445.00	\N	TL	t	2025-10-28 23:49:23.076901	2025-10-28 23:49:23.076901
225	13	DEMRE	HAVALİMANI	\N	6235.00	9430.00	15285.00	\N	TL	t	2025-10-28 23:49:23.077273	2025-10-28 23:49:23.077273
226	13	KAŞ	HAVALİMANI	\N	7440.00	11720.00	19775.00	\N	TL	t	2025-10-28 23:49:23.07769	2025-10-28 23:49:23.07769
227	13	FETHİYE	HAVALİMANI	\N	8205.00	13210.00	22220.00	\N	TL	t	2025-10-28 23:49:23.078029	2025-10-28 23:49:23.078029
228	13	DALAMAN	HAVALİMANI	\N	9160.00	14665.00	24685.00	\N	TL	t	2025-10-28 23:49:23.078358	2025-10-28 23:49:23.078358
229	13	MARMARİS	HAVALİMANI	\N	12790.00	20550.00	34595.00	\N	TL	t	2025-10-28 23:49:23.078713	2025-10-28 23:49:23.078713
230	13	BODRUM	HAVALİMANI	\N	16455.00	26410.00	44475.00	\N	TL	t	2025-10-28 23:49:23.079063	2025-10-28 23:49:23.079063
231	13	GAZİPAŞA	ALANYA	\N	3120.00	4800.00	8000.00	\N	TL	t	2025-10-28 23:49:23.07941	2025-10-28 23:49:23.07941
232	13	GAZİPAŞA	SİDE	\N	3880.00	6050.00	10100.00	\N	TL	t	2025-10-28 23:49:23.079791	2025-10-28 23:49:23.079791
233	13	GAZİPAŞA	BELEK	\N	4600.00	7200.00	12100.00	\N	TL	t	2025-10-28 23:49:23.080122	2025-10-28 23:49:23.080122
234	13	GAZİPAŞA	ANTALYA	\N	5350.00	8450.00	14100.00	\N	TL	t	2025-10-28 23:49:23.080448	2025-10-28 23:49:23.080448
235	13	GAZİPAŞA	KEMER	\N	6550.00	10300.00	17250.00	\N	TL	t	2025-10-28 23:49:23.080775	2025-10-28 23:49:23.080775
236	13	MANAVGAT BOT TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.081123	2025-10-28 23:49:23.081123
237	13	MANAVGAT BOT TURU	KEMER	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 23:49:23.081532	2025-10-28 23:49:23.081532
238	13	MANAVGAT BOT TURU	BELEK	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 23:49:23.081905	2025-10-28 23:49:23.081905
239	13	MANAVGAT BOT TURU	SİDE	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 23:49:23.082236	2025-10-28 23:49:23.082236
240	13	MANAVGAT BOT TURU	ALANYA	\N	6030.00	8695.00	13220.00	\N	TL	t	2025-10-28 23:49:23.082583	2025-10-28 23:49:23.082583
241	13	DISCOVERY PARK TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.082912	2025-10-28 23:49:23.082912
242	13	DISCOVERY PARK TURU	KEMER	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 23:49:23.083308	2025-10-28 23:49:23.083308
243	13	DISCOVERY PARK TURU	BELEK	\N	4380.00	6940.00	10780.00	\N	TL	t	2025-10-28 23:49:23.083662	2025-10-28 23:49:23.083662
244	13	DISCOVERY PARK TURU	SİDE	\N	3880.00	5540.00	8400.00	\N	TL	t	2025-10-28 23:49:23.083988	2025-10-28 23:49:23.083988
245	13	DISCOVERY PARK TURU	ALANYA	\N	5030.00	7330.00	11175.00	\N	TL	t	2025-10-28 23:49:23.084315	2025-10-28 23:49:23.084315
246	13	BELEK LAND OF LEGENDS TURU	ANTALYA	\N	5360.00	7590.00	11480.00	\N	TL	t	2025-10-28 23:49:23.084645	2025-10-28 23:49:23.084645
247	13	BELEK LAND OF LEGENDS TURU	KEMER	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.084971	2025-10-28 23:49:23.084971
248	13	BELEK LAND OF LEGENDS TURU	BELEK	\N	4815.00	6935.00	10735.00	\N	TL	t	2025-10-28 23:49:23.085386	2025-10-28 23:49:23.085386
249	13	BELEK LAND OF LEGENDS TURU	SİDE	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 23:49:23.085759	2025-10-28 23:49:23.085759
250	13	BELEK LAND OF LEGENDS TURU	ALANYA	\N	6425.00	9430.00	14375.00	\N	TL	t	2025-10-28 23:49:23.08609	2025-10-28 23:49:23.08609
251	13	AQUALAND TURU / AKVARYUM TURU	ANTALYA	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 23:49:23.086418	2025-10-28 23:49:23.086418
252	13	AQUALAND TURU / AKVARYUM TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 23:49:23.086779	2025-10-28 23:49:23.086779
253	13	AQUALAND TURU / AKVARYUM TURU	BELEK	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 23:49:23.087121	2025-10-28 23:49:23.087121
254	13	AQUALAND TURU / AKVARYUM TURU	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.087525	2025-10-28 23:49:23.087525
255	13	AQUALAND TURU / AKVARYUM TURU	ALANYA	\N	6815.00	10155.00	15530.00	\N	TL	t	2025-10-28 23:49:23.087972	2025-10-28 23:49:23.087972
256	13	TÜNEKTEPE TELEFERİK TURU	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 23:49:23.088463	2025-10-28 23:49:23.088463
257	13	TÜNEKTEPE TELEFERİK TURU	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 23:49:23.089064	2025-10-28 23:49:23.089064
258	13	TÜNEKTEPE TELEFERİK TURU	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.089724	2025-10-28 23:49:23.089724
259	13	TÜNEKTEPE TELEFERİK TURU	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.090152	2025-10-28 23:49:23.090152
260	13	TÜNEKTEPE TELEFERİK TURU	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 23:49:23.090507	2025-10-28 23:49:23.090507
261	13	ANTALYA YAT TURU SETUR MARİNA	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 23:49:23.090871	2025-10-28 23:49:23.090871
262	13	ANTALYA YAT TURU SETUR MARİNA	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 23:49:23.091269	2025-10-28 23:49:23.091269
263	13	ANTALYA YAT TURU SETUR MARİNA	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.091699	2025-10-28 23:49:23.091699
264	13	ANTALYA YAT TURU SETUR MARİNA	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.092069	2025-10-28 23:49:23.092069
265	13	ANTALYA YAT TURU SETUR MARİNA	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 23:49:23.092418	2025-10-28 23:49:23.092418
266	13	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	ANTALYA	\N	5410.00	7690.00	11640.00	\N	TL	t	2025-10-28 23:49:23.092857	2025-10-28 23:49:23.092857
267	13	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	KEMER	\N	5140.00	7525.00	11680.00	\N	TL	t	2025-10-28 23:49:23.093227	2025-10-28 23:49:23.093227
268	13	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.093599	2025-10-28 23:49:23.093599
269	13	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	SİDE	\N	6120.00	8980.00	13690.00	\N	TL	t	2025-10-28 23:49:23.093958	2025-10-28 23:49:23.093958
270	13	ANTALYA MACERA PARK TURU / HAYVANAT BAHÇESİ TURU	ALANYA	\N	6995.00	10470.00	16025.00	\N	TL	t	2025-10-28 23:49:23.094294	2025-10-28 23:49:23.094294
271	13	ANTALYA ŞEHİR TURU	ANTALYA	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 23:49:23.094628	2025-10-28 23:49:23.094628
272	13	ANTALYA ŞEHİR TURU	KEMER	\N	5785.00	8710.00	13565.00	\N	TL	t	2025-10-28 23:49:23.094959	2025-10-28 23:49:23.094959
273	13	ANTALYA ŞEHİR TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 23:49:23.095409	2025-10-28 23:49:23.095409
274	13	ANTALYA ŞEHİR TURU	SİDE	\N	6220.00	9170.00	14000.00	\N	TL	t	2025-10-28 23:49:23.095832	2025-10-28 23:49:23.095832
275	13	ANTALYA ŞEHİR TURU	ALANYA	\N	7275.00	10985.00	16855.00	\N	TL	t	2025-10-28 23:49:23.096174	2025-10-28 23:49:23.096174
276	13	ALANYA ŞEHİR TURU	SİDE	\N	5950.00	8680.00	13220.00	\N	TL	t	2025-10-28 23:49:23.096505	2025-10-28 23:49:23.096505
277	13	ALANYA ŞEHİR TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 23:49:23.096837	2025-10-28 23:49:23.096837
278	13	ALARAHAN PİKNİK TURU	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.097234	2025-10-28 23:49:23.097234
279	13	ALARAHAN PİKNİK TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 23:49:23.097597	2025-10-28 23:49:23.097597
280	13	ALANYA BOT TURU	SİDE	\N	5670.00	8495.00	13225.00	\N	TL	t	2025-10-28 23:49:23.097932	2025-10-28 23:49:23.097932
281	13	ALANYA BOT TURU	ALANYA	\N	5795.00	8285.00	12560.00	\N	TL	t	2025-10-28 23:49:23.098261	2025-10-28 23:49:23.098261
282	13	WATER PLANET	SİDE	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.098591	2025-10-28 23:49:23.098591
283	13	WATER PLANET	ALANYA	\N	5745.00	8180.00	12390.00	\N	TL	t	2025-10-28 23:49:23.098922	2025-10-28 23:49:23.098922
284	13	SEA ALANYA DOLPHIN TURU	ANTALYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.099277	2025-10-28 23:49:23.099277
285	13	SEA ALANYA DOLPHIN TURU	KEMER	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 23:49:23.09961	2025-10-28 23:49:23.09961
286	13	SEA ALANYA DOLPHIN TURU	BELEK	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.099941	2025-10-28 23:49:23.099941
287	13	SEA ALANYA DOLPHIN TURU	SİDE	\N	4890.00	7180.00	10950.00	\N	TL	t	2025-10-28 23:49:23.100274	2025-10-28 23:49:23.100274
288	13	SEA ALANYA DOLPHIN TURU	ALANYA	\N	4360.00	6345.00	9650.00	\N	TL	t	2025-10-28 23:49:23.100604	2025-10-28 23:49:23.100604
289	13	SEA ALANYA TAM GÜN	ANTALYA	\N	6390.00	9470.00	14480.00	\N	TL	t	2025-10-28 23:49:23.100935	2025-10-28 23:49:23.100935
290	13	SEA ALANYA TAM GÜN	KEMER	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 23:49:23.10132	2025-10-28 23:49:23.10132
291	13	SEA ALANYA TAM GÜN	BELEK	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.101758	2025-10-28 23:49:23.101758
292	13	SEA ALANYA TAM GÜN	SİDE	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 23:49:23.102094	2025-10-28 23:49:23.102094
293	13	SEA ALANYA TAM GÜN	ALANYA	\N	5860.00	8390.00	12715.00	\N	TL	t	2025-10-28 23:49:23.102441	2025-10-28 23:49:23.102441
294	13	SİDE ŞEHİR TURU	SİDE	\N	5520.00	7890.00	11960.00	\N	TL	t	2025-10-28 23:49:23.102777	2025-10-28 23:49:23.102777
295	13	SİDE ŞEHİR TURU	ALANYA	\N	6250.00	9115.00	13880.00	\N	TL	t	2025-10-28 23:49:23.103128	2025-10-28 23:49:23.103128
296	13	BEŞKONAK TURU	ANTALYA	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.103549	2025-10-28 23:49:23.104722
297	13	BEŞKONAK TURU	KEMER	\N	6435.00	9900.00	15455.00	\N	TL	t	2025-10-28 23:49:23.103923	2025-10-28 23:49:23.10555
298	13	BEŞKONAK TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 23:49:23.104261	2025-10-28 23:49:23.106088
299	13	BEŞKONAK TURU	SİDE	\N	6060.00	8880.00	13530.00	\N	TL	t	2025-10-28 23:49:23.106595	2025-10-28 23:49:23.106595
300	13	BEŞKONAK TURU	ALANYA	\N	6880.00	10260.00	15700.00	\N	TL	t	2025-10-28 23:49:23.106994	2025-10-28 23:49:23.106994
301	13	TAZI KANYONU TURU	ANTALYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.107448	2025-10-28 23:49:23.107448
302	13	TAZI KANYONU TURU	KEMER	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.107817	2025-10-28 23:49:23.107817
303	13	TAZI KANYONU TURU	BELEK	\N	5490.00	8175.00	12710.00	\N	TL	t	2025-10-28 23:49:23.108156	2025-10-28 23:49:23.108156
304	13	TAZI KANYONU TURU	SİDE	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.1085	2025-10-28 23:49:23.1085
305	13	TAZI KANYONU TURU	ALANYA	\N	7160.00	10775.00	16530.00	\N	TL	t	2025-10-28 23:49:23.108835	2025-10-28 23:49:23.108835
306	13	ASPENDOS KONSER TURU	ANTALYA	\N	4090.00	5940.00	9030.00	\N	TL	t	2025-10-28 23:49:23.109193	2025-10-28 23:49:23.109193
307	13	ASPENDOS KONSER TURU	KEMER	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.109589	2025-10-28 23:49:23.109589
308	13	ASPENDOS KONSER TURU	BELEK	\N	2660.00	3925.00	6095.00	\N	TL	t	2025-10-28 23:49:23.10993	2025-10-28 23:49:23.10993
309	13	ASPENDOS KONSER TURU	SİDE	\N	3980.00	5740.00	8720.00	\N	TL	t	2025-10-28 23:49:23.110265	2025-10-28 23:49:23.110265
310	13	ASPENDOS KONSER TURU	ALANYA	\N	6365.00	9325.00	14205.00	\N	TL	t	2025-10-28 23:49:23.110608	2025-10-28 23:49:23.110608
311	13	OYMAPINAR PİKNİK TURU	ANTALYA	\N	5950.00	8680.00	13225.00	\N	TL	t	2025-10-28 23:49:23.111052	2025-10-28 23:49:23.111052
312	13	OYMAPINAR PİKNİK TURU	KEMER	\N	6435.00	9900.00	15455.00	\N	TL	t	2025-10-28 23:49:23.111433	2025-10-28 23:49:23.111433
313	13	OYMAPINAR PİKNİK TURU	BELEK	\N	5375.00	7960.00	12365.00	\N	TL	t	2025-10-28 23:49:23.111782	2025-10-28 23:49:23.111782
314	13	OYMAPINAR PİKNİK TURU	SİDE	\N	5310.00	7490.00	11330.00	\N	TL	t	2025-10-28 23:49:23.112123	2025-10-28 23:49:23.112123
315	13	OYMAPINAR PİKNİK TURU	ALANYA	\N	6250.00	9115.00	13880.00	\N	TL	t	2025-10-28 23:49:23.112489	2025-10-28 23:49:23.112489
316	13	KARACAÖREN PİKNİK TURU	ANTALYA	\N	5850.00	8480.00	12900.00	\N	TL	t	2025-10-28 23:49:23.112873	2025-10-28 23:49:23.112873
317	13	KARACAÖREN PİKNİK TURU	KEMER	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.113297	2025-10-28 23:49:23.113297
318	13	KARACAÖREN PİKNİK TURU	BELEK	\N	5610.00	8390.00	13050.00	\N	TL	t	2025-10-28 23:49:23.113679	2025-10-28 23:49:23.113679
319	13	KARACAÖREN PİKNİK TURU	SİDE	\N	6080.00	9250.00	14425.00	\N	TL	t	2025-10-28 23:49:23.114019	2025-10-28 23:49:23.114019
320	13	KARACAÖREN PİKNİK TURU	ALANYA	\N	7275.00	10985.00	16855.00	\N	TL	t	2025-10-28 23:49:23.114357	2025-10-28 23:49:23.114357
321	13	DEMRE KEKOVA TURU	ANTALYA	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.114693	2025-10-28 23:49:23.114693
322	13	DEMRE KEKOVA TURU	KEMER	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.11507	2025-10-28 23:49:23.11507
323	13	DEMRE KEKOVA TURU	BELEK	\N	7020.00	10975.00	17170.00	\N	TL	t	2025-10-28 23:49:23.115425	2025-10-28 23:49:23.115425
324	13	DEMRE KEKOVA TURU	SİDE	\N	7435.00	11730.00	18370.00	\N	TL	t	2025-10-28 23:49:23.115763	2025-10-28 23:49:23.115763
325	13	DEMRE KEKOVA TURU	ALANYA	\N	8695.00	13590.00	21000.00	\N	TL	t	2025-10-28 23:49:23.116128	2025-10-28 23:49:23.116128
326	13	PAMUKKALE 1 GÜN	ANTALYA	\N	8500.00	13000.00	21500.00	\N	TL	t	2025-10-28 23:49:23.116465	2025-10-28 23:49:23.116465
327	13	PAMUKKALE 1 GÜN	KEMER	\N	9190.00	14065.00	23345.00	\N	TL	t	2025-10-28 23:49:23.116807	2025-10-28 23:49:23.116807
328	13	PAMUKKALE 1 GÜN	BELEK	\N	9190.00	14065.00	23345.00	\N	TL	t	2025-10-28 23:49:23.117201	2025-10-28 23:49:23.117201
329	13	PAMUKKALE 1 GÜN	SİDE	\N	8490.00	13670.00	21455.00	\N	TL	t	2025-10-28 23:49:23.117601	2025-10-28 23:49:23.117601
330	13	PAMUKKALE 1 GÜN	ALANYA	\N	9255.00	15070.00	23685.00	\N	TL	t	2025-10-28 23:49:23.117948	2025-10-28 23:49:23.117948
331	13	PAMUKKALE SALDA TURU	ANTALYA	\N	9500.00	15000.00	24750.00	\N	TL	t	2025-10-28 23:49:23.118288	2025-10-28 23:49:23.118288
332	13	PAMUKKALE SALDA TURU	KEMER	\N	10315.00	15940.00	25780.00	\N	TL	t	2025-10-28 23:49:23.118626	2025-10-28 23:49:23.118626
333	13	PAMUKKALE SALDA TURU	BELEK	\N	10315.00	15940.00	25780.00	\N	TL	t	2025-10-28 23:49:23.118965	2025-10-28 23:49:23.118965
334	13	PAMUKKALE SALDA TURU	SİDE	\N	8785.00	14210.00	22315.00	\N	TL	t	2025-10-28 23:49:23.119358	2025-10-28 23:49:23.119358
335	13	PAMUKKALE SALDA TURU	ALANYA	\N	9550.00	15610.00	24540.00	\N	TL	t	2025-10-28 23:49:23.119707	2025-10-28 23:49:23.119707
336	13	PAMUKKALE 2 GÜN	ANTALYA	\N	12570.00	19255.00	30050.00	\N	TL	t	2025-10-28 23:49:23.120048	2025-10-28 23:49:23.120048
337	13	PAMUKKALE 2 GÜN	KEMER	\N	13040.00	20120.00	31420.00	\N	TL	t	2025-10-28 23:49:23.120387	2025-10-28 23:49:23.120387
338	13	PAMUKKALE 2 GÜN	BELEK	\N	12690.00	19475.00	30390.00	\N	TL	t	2025-10-28 23:49:23.120726	2025-10-28 23:49:23.120726
339	13	PAMUKKALE 2 GÜN	SİDE	\N	13280.00	20550.00	32105.00	\N	TL	t	2025-10-28 23:49:23.121105	2025-10-28 23:49:23.121105
340	13	PAMUKKALE 2 GÜN	ALANYA	\N	15110.00	23005.00	35365.00	\N	TL	t	2025-10-28 23:49:23.121597	2025-10-28 23:49:23.121597
341	13	KAPADOKYA 2 GÜN	ANTALYA	\N	19000.00	29000.00	46000.00	\N	TL	t	2025-10-28 23:49:23.122247	2025-10-28 23:49:23.122247
342	13	KAPADOKYA 2 GÜN	KEMER	\N	17215.00	27775.00	43595.00	\N	TL	t	2025-10-28 23:49:23.12294	2025-10-28 23:49:23.12294
343	13	KAPADOKYA 2 GÜN	BELEK	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 23:49:23.123532	2025-10-28 23:49:23.123532
344	13	KAPADOKYA 2 GÜN	SİDE	\N	15805.00	25185.00	39480.00	\N	TL	t	2025-10-28 23:49:23.123935	2025-10-28 23:49:23.123935
345	13	KAPADOKYA 2 GÜN	ALANYA	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 23:49:23.124316	2025-10-28 23:49:23.124316
346	13	EFES PAMUKKALE 2 GÜN	ANTALYA	\N	18000.00	27000.00	45000.00	\N	TL	t	2025-10-28 23:49:23.124681	2025-10-28 23:49:23.124681
347	13	EFES PAMUKKALE 2 GÜN	KEMER	\N	18750.00	28125.00	48750.00	\N	TL	t	2025-10-28 23:49:23.125036	2025-10-28 23:49:23.125036
348	13	EFES PAMUKKALE 2 GÜN	BELEK	\N	17815.00	26250.00	44065.00	\N	TL	t	2025-10-28 23:49:23.125486	2025-10-28 23:49:23.125486
349	13	EFES PAMUKKALE 2 GÜN	SİDE	\N	16980.00	27340.00	42910.00	\N	TL	t	2025-10-28 23:49:23.125863	2025-10-28 23:49:23.125863
350	13	EFES PAMUKKALE 2 GÜN	ALANYA	\N	19080.00	30285.00	46935.00	\N	TL	t	2025-10-28 23:49:23.126212	2025-10-28 23:49:23.126212
351	13	DEMRE PAMUKKALE TURU 2 GÜN	ANTALYA	\N	16000.00	21910.00	39000.00	\N	TL	t	2025-10-28 23:49:23.126651	2025-10-28 23:49:23.126651
352	13	DEMRE PAMUKKALE TURU 2 GÜN	KEMER	\N	15220.00	24110.00	37765.00	\N	TL	t	2025-10-28 23:49:23.127017	2025-10-28 23:49:23.127017
353	13	DEMRE PAMUKKALE TURU 2 GÜN	BELEK	\N	14630.00	23030.00	36050.00	\N	TL	t	2025-10-28 23:49:23.127422	2025-10-28 23:49:23.127422
354	13	DEMRE PAMUKKALE TURU 2 GÜN	SİDE	\N	15220.00	24110.00	37765.00	\N	TL	t	2025-10-28 23:49:23.127789	2025-10-28 23:49:23.127789
355	13	DEMRE PAMUKKALE TURU 2 GÜN	ALANYA	\N	16100.00	25725.00	40340.00	\N	TL	t	2025-10-28 23:49:23.128137	2025-10-28 23:49:23.128137
356	13	KAŞ TURU	ANTALYA	\N	7610.00	12055.00	18885.00	\N	TL	t	2025-10-28 23:49:23.12848	2025-10-28 23:49:23.12848
357	13	KAŞ TURU	KEMER	\N	6550.00	10115.00	15795.00	\N	TL	t	2025-10-28 23:49:23.128823	2025-10-28 23:49:23.128823
358	13	KEMER ŞEHİR TURU	ANTALYA	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 23:49:23.129167	2025-10-28 23:49:23.129167
359	13	KEMER ŞEHİR TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 23:49:23.129516	2025-10-28 23:49:23.129516
360	13	KEMER ŞEHİR TURU	BELEK	\N	6200.00	9465.00	14765.00	\N	TL	t	2025-10-28 23:49:23.129858	2025-10-28 23:49:23.129858
361	13	KEMER ŞEHİR TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.130213	2025-10-28 23:49:23.130213
362	13	KEMER ŞEHİR TURU	ALANYA	\N	8010.00	12340.00	19005.00	\N	TL	t	2025-10-28 23:49:23.130582	2025-10-28 23:49:23.130582
363	13	ADRASAN SULUADA TURU	ANTALYA	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 23:49:23.130958	2025-10-28 23:49:23.130958
364	13	ADRASAN SULUADA TURU	KEMER	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.131383	2025-10-28 23:49:23.131383
365	13	ADRASAN SULUADA TURU	BELEK	\N	6255.00	9575.00	14940.00	\N	TL	t	2025-10-28 23:49:23.131806	2025-10-28 23:49:23.131806
366	13	ADRASAN SULUADA TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.132161	2025-10-28 23:49:23.132161
367	13	ADRASAN SULUADA TURU	ALANYA	\N	8130.00	12550.00	19330.00	\N	TL	t	2025-10-28 23:49:23.132541	2025-10-28 23:49:23.132541
368	13	KEMER BOT TURU	ANTALYA	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.132891	2025-10-28 23:49:23.132891
369	13	KEMER BOT TURU	KEMER	\N	4965.00	7205.00	11165.00	\N	TL	t	2025-10-28 23:49:23.133274	2025-10-28 23:49:23.133274
370	13	KEMER BOT TURU	BELEK	\N	5725.00	8605.00	13395.00	\N	TL	t	2025-10-28 23:49:23.133643	2025-10-28 23:49:23.133643
371	13	KEMER BOT TURU	SİDE	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.133993	2025-10-28 23:49:23.133993
372	13	KEMER BOT TURU	ALANYA	\N	7560.00	11510.00	17685.00	\N	TL	t	2025-10-28 23:49:23.134339	2025-10-28 23:49:23.134339
373	13	GÖYNÜK DİNOPARK TURU	ANTALYA	\N	5630.00	8080.00	12270.00	\N	TL	t	2025-10-28 23:49:23.134685	2025-10-28 23:49:23.134685
374	13	GÖYNÜK DİNOPARK TURU	KEMER	\N	4965.00	7205.00	11165.00	\N	TL	t	2025-10-28 23:49:23.135034	2025-10-28 23:49:23.135034
375	13	GÖYNÜK DİNOPARK TURU	BELEK	\N	5610.00	8390.00	13050.00	\N	TL	t	2025-10-28 23:49:23.135435	2025-10-28 23:49:23.135435
376	13	TAHTALI TURU	ANTALYA	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.135788	2025-10-28 23:49:23.135788
377	13	TAHTALI TURU	KEMER	\N	5080.00	7420.00	11510.00	\N	TL	t	2025-10-28 23:49:23.136152	2025-10-28 23:49:23.136152
378	13	TAHTALI TURU	BELEK	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 23:49:23.136497	2025-10-28 23:49:23.136497
379	13	TAHTALI TURU	SİDE	\N	6490.00	10005.00	15625.00	\N	TL	t	2025-10-28 23:49:23.136842	2025-10-28 23:49:23.136842
380	13	TAHTALI TURU	ALANYA	\N	7780.00	11920.00	18345.00	\N	TL	t	2025-10-28 23:49:23.137211	2025-10-28 23:49:23.137211
381	13	TAHTALI + AKVARYUM TURU	ANTALYA	\N	6120.00	9500.00	15000.00	\N	TL	t	2025-10-28 23:49:23.137562	2025-10-28 23:49:23.137562
382	13	TAHTALI + AKVARYUM TURU	KEMER	\N	5670.00	8495.00	13225.00	\N	TL	t	2025-10-28 23:49:23.137995	2025-10-28 23:49:23.137995
383	13	TAHTALI + AKVARYUM TURU	BELEK	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 23:49:23.138565	2025-10-28 23:49:23.138565
384	13	TAHTALI + AKVARYUM TURU	SİDE	\N	6490.00	10005.00	15625.00	\N	TL	t	2025-10-28 23:49:23.139125	2025-10-28 23:49:23.139125
385	13	TAHTALI + AKVARYUM TURU	ALANYA	\N	7780.00	11920.00	18345.00	\N	TL	t	2025-10-28 23:49:23.139735	2025-10-28 23:49:23.139735
386	13	ULUPINAR OLİMPOS PHASELİS TURU	ANTALYA	\N	6280.00	9270.00	14160.00	\N	TL	t	2025-10-28 23:49:23.140208	2025-10-28 23:49:23.140208
387	13	ULUPINAR OLİMPOS PHASELİS TURU	KEMER	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.140617	2025-10-28 23:49:23.140617
388	13	ULUPINAR OLİMPOS PHASELİS TURU	BELEK	\N	6200.00	9465.00	14765.00	\N	TL	t	2025-10-28 23:49:23.140972	2025-10-28 23:49:23.140972
389	13	ULUPINAR OLİMPOS PHASELİS TURU	SİDE	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.141384	2025-10-28 23:49:23.141384
390	13	ULUPINAR OLİMPOS PHASELİS TURU	ALANYA	\N	8010.00	12340.00	19005.00	\N	TL	t	2025-10-28 23:49:23.141754	2025-10-28 23:49:23.141754
391	13	PERGE ANTALYA TURU	ANTALYA	\N	5630.00	8080.00	12270.00	\N	TL	t	2025-10-28 23:49:23.142106	2025-10-28 23:49:23.142106
392	13	PERGE ANTALYA TURU	KEMER	\N	6020.00	9145.00	14250.00	\N	TL	t	2025-10-28 23:49:23.142494	2025-10-28 23:49:23.142494
393	13	PERGE ANTALYA TURU	BELEK	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 23:49:23.142875	2025-10-28 23:49:23.142875
394	13	PERGE ANTALYA TURU	SİDE	\N	5965.00	9035.00	14080.00	\N	TL	t	2025-10-28 23:49:23.143235	2025-10-28 23:49:23.143235
395	13	PERGE ANTALYA TURU	ALANYA	\N	6725.00	10435.00	16310.00	\N	TL	t	2025-10-28 23:49:23.143589	2025-10-28 23:49:23.143589
396	13	PERGE ASPENDOS SİDE	ANTALYA	\N	5725.00	8605.00	13395.00	\N	TL	t	2025-10-28 23:49:23.143938	2025-10-28 23:49:23.143938
397	13	PERGE ASPENDOS SİDE	KEMER	\N	6375.00	9790.00	15280.00	\N	TL	t	2025-10-28 23:49:23.144288	2025-10-28 23:49:23.144288
398	13	PERGE ASPENDOS SİDE	BELEK	\N	5435.00	8065.00	12535.00	\N	TL	t	2025-10-28 23:49:23.144694	2025-10-28 23:49:23.144694
399	13	PERGE ASPENDOS SİDE	SİDE	\N	5845.00	8820.00	13740.00	\N	TL	t	2025-10-28 23:49:23.145084	2025-10-28 23:49:23.145084
400	13	PERGE ASPENDOS SİDE	ALANYA	\N	6670.00	10330.00	16140.00	\N	TL	t	2025-10-28 23:49:23.145471	2025-10-28 23:49:23.145471
401	13	ANTALYA AKŞAM YEMEK TURU	ANTALYA	\N	3970.00	5760.00	8930.00	\N	TL	t	2025-10-28 23:49:23.145854	2025-10-28 23:49:23.145854
402	13	ANTALYA AKŞAM YEMEK TURU	KEMER	\N	5255.00	7740.00	12025.00	\N	TL	t	2025-10-28 23:49:23.146235	2025-10-28 23:49:23.146235
403	13	ANTALYA AKŞAM YEMEK TURU	BELEK	\N	4205.00	6195.00	9620.00	\N	TL	t	2025-10-28 23:49:23.14662	2025-10-28 23:49:23.14662
404	13	ANTALYA AKŞAM YEMEK TURU	SİDE	\N	5550.00	8280.00	12880.00	\N	TL	t	2025-10-28 23:49:23.147008	2025-10-28 23:49:23.147008
405	13	ANTALYA AKŞAM YEMEK TURU	ALANYA	\N	6140.00	9360.00	14595.00	\N	TL	t	2025-10-28 23:49:23.147424	2025-10-28 23:49:23.147424
406	13	KEMER	KEMER	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 23:49:23.147874	2025-10-28 23:49:23.147874
407	13	KEMER	ANTALYA	\N	2510.00	3895.00	5950.00	\N	TL	t	2025-10-28 23:49:23.148258	2025-10-28 23:49:23.148258
408	13	KEMER	BELEK	\N	4150.00	6470.00	9890.00	\N	TL	t	2025-10-28 23:49:23.148656	2025-10-28 23:49:23.148656
409	13	KEMER	SİDE	\N	5480.00	8665.00	13375.00	\N	TL	t	2025-10-28 23:49:23.149387	2025-10-28 23:49:23.149387
410	13	KEMER	ALANYA	\N	7570.00	12085.00	18610.00	\N	TL	t	2025-10-28 23:49:23.149772	2025-10-28 23:49:23.149772
411	13	ANTALYA	ANTALYA	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 23:49:23.150155	2025-10-28 23:49:23.150155
412	13	ANTALYA	BELEK	\N	2160.00	3275.00	4915.00	\N	TL	t	2025-10-28 23:49:23.150534	2025-10-28 23:49:23.150534
413	13	ANTALYA	SİDE	\N	3115.00	4870.00	7360.00	\N	TL	t	2025-10-28 23:49:23.150913	2025-10-28 23:49:23.150913
414	13	ANTALYA	ALANYA	\N	4355.00	6865.00	10565.00	\N	TL	t	2025-10-28 23:49:23.151296	2025-10-28 23:49:23.151296
415	13	BELEK	BELEK	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 23:49:23.151679	2025-10-28 23:49:23.151679
416	13	BELEK	SİDE	\N	2420.00	3700.00	5650.00	\N	TL	t	2025-10-28 23:49:23.152059	2025-10-28 23:49:23.152059
417	13	BELEK	ALANYA	\N	3985.00	6255.00	9505.00	\N	TL	t	2025-10-28 23:49:23.15244	2025-10-28 23:49:23.15244
418	13	SİDE	SİDE	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 23:49:23.152822	2025-10-28 23:49:23.152822
419	13	SİDE	ALANYA	\N	3115.00	4870.00	7360.00	\N	TL	t	2025-10-28 23:49:23.15323	2025-10-28 23:49:23.15323
420	13	BÖLGE İÇİ ARA TRANSFER	ARA TRANSFER	\N	1800.00	2665.00	4075.00	\N	TL	t	2025-10-28 23:49:23.153646	2025-10-28 23:49:23.153646
\.


--
-- Data for Name: vehicle_contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_contracts (id, vehicle_company_id, contract_code, start_date, end_date, created_at, updated_at, is_active, archived_at, replaced_by_id) FROM stdin;
12	1	FST-001	2025-10-01	2025-12-31	2025-10-28 20:35:24.715222	2025-10-28 23:35:16.992112	t	\N	\N
13	2	FST-002	2025-01-01	2025-12-31	2025-10-28 23:49:11.762891	2025-10-28 23:49:11.762891	t	\N	\N
\.


--
-- Data for Name: vehicle_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_types (id, name, vehicle_company_id, created_at, updated_at) FROM stdin;
1	Mini	1	2025-10-26 23:31:54.917652	\N
2	Midi	1	2025-10-26 23:32:01.320662	\N
3	Bus	1	2025-10-26 23:32:08.013198	\N
4	Vito	1	2025-10-26 23:32:15.750468	\N
5	Vip Mini	1	2025-10-26 23:32:24.623267	\N
6	Vip Vito	1	2025-10-26 23:32:33.817543	\N
7	S25Y	1	2025-10-27 18:46:33.663321	\N
8	test	2	2025-10-28 23:48:57.503642	\N
\.


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cities_id_seq', 7, true);


--
-- Name: contract_action_regional_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_action_regional_prices_id_seq', 7, true);


--
-- Name: contract_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_actions_id_seq', 3, true);


--
-- Name: contract_kickback_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_kickback_periods_id_seq', 3, true);


--
-- Name: contract_price_period_regional_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_price_period_regional_prices_id_seq', 28, true);


--
-- Name: contract_price_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_price_periods_id_seq', 4, true);


--
-- Name: contract_regional_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_regional_prices_id_seq', 42, true);


--
-- Name: contract_transfer_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_transfer_periods_id_seq', 4, true);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contracts_id_seq', 4, true);


--
-- Name: costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.costs_id_seq', 35, true);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.countries_id_seq', 36, true);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.currencies_id_seq', 5, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_id_seq', 2, true);


--
-- Name: merchants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.merchants_id_seq', 5, true);


--
-- Name: positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.positions_id_seq', 6, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.regions_id_seq', 35, true);


--
-- Name: sub_regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sub_regions_id_seq', 7, true);


--
-- Name: tour_contract_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tour_contract_routes_id_seq', 6, true);


--
-- Name: tour_sub_regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tour_sub_regions_id_seq', 14, true);


--
-- Name: tours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tours_id_seq', 5, true);


--
-- Name: transfer_period_group_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transfer_period_group_ranges_id_seq', 3, true);


--
-- Name: transfer_period_regional_group_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transfer_period_regional_group_ranges_id_seq', 1, false);


--
-- Name: transfer_period_regional_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transfer_period_regional_prices_id_seq', 14, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: vehicle_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_companies_id_seq', 2, true);


--
-- Name: vehicle_contract_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_contract_routes_id_seq', 420, true);


--
-- Name: vehicle_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_contracts_id_seq', 13, true);


--
-- Name: vehicle_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehicle_types_id_seq', 8, true);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: contract_action_regional_prices contract_action_regional_prices_action_id_sub_region_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_action_regional_prices
    ADD CONSTRAINT contract_action_regional_prices_action_id_sub_region_id_key UNIQUE (action_id, sub_region_id);


--
-- Name: contract_action_regional_prices contract_action_regional_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_action_regional_prices
    ADD CONSTRAINT contract_action_regional_prices_pkey PRIMARY KEY (id);


--
-- Name: contract_actions contract_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_actions
    ADD CONSTRAINT contract_actions_pkey PRIMARY KEY (id);


--
-- Name: contract_kickback_periods contract_kickback_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_kickback_periods
    ADD CONSTRAINT contract_kickback_periods_pkey PRIMARY KEY (id);


--
-- Name: contract_price_period_regional_prices contract_price_period_regiona_price_period_id_sub_region_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_period_regional_prices
    ADD CONSTRAINT contract_price_period_regiona_price_period_id_sub_region_id_key UNIQUE (price_period_id, sub_region_id);


--
-- Name: contract_price_period_regional_prices contract_price_period_regional_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_period_regional_prices
    ADD CONSTRAINT contract_price_period_regional_prices_pkey PRIMARY KEY (id);


--
-- Name: contract_price_periods contract_price_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_periods
    ADD CONSTRAINT contract_price_periods_pkey PRIMARY KEY (id);


--
-- Name: contract_regional_prices contract_regional_prices_contract_id_sub_region_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_regional_prices
    ADD CONSTRAINT contract_regional_prices_contract_id_sub_region_id_key UNIQUE (contract_id, sub_region_id);


--
-- Name: contract_regional_prices contract_regional_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_regional_prices
    ADD CONSTRAINT contract_regional_prices_pkey PRIMARY KEY (id);


--
-- Name: contract_transfer_periods contract_transfer_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_transfer_periods
    ADD CONSTRAINT contract_transfer_periods_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_contract_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_contract_code_key UNIQUE (contract_code);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: costs costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT costs_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_code_key UNIQUE (code);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: sub_regions sub_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_regions
    ADD CONSTRAINT sub_regions_pkey PRIMARY KEY (id);


--
-- Name: tour_contract_routes tour_contract_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes
    ADD CONSTRAINT tour_contract_routes_pkey PRIMARY KEY (id);


--
-- Name: tour_contract_routes tour_contract_routes_tour_id_sub_region_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes
    ADD CONSTRAINT tour_contract_routes_tour_id_sub_region_id_key UNIQUE (tour_id, sub_region_id);


--
-- Name: tour_sub_regions tour_sub_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_sub_regions
    ADD CONSTRAINT tour_sub_regions_pkey PRIMARY KEY (id);


--
-- Name: tour_sub_regions tour_sub_regions_tour_id_sub_region_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_sub_regions
    ADD CONSTRAINT tour_sub_regions_tour_id_sub_region_id_key UNIQUE (tour_id, sub_region_id);


--
-- Name: tours tours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_pkey PRIMARY KEY (id);


--
-- Name: tours tours_sejour_tour_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_sejour_tour_code_key UNIQUE (sejour_tour_code);


--
-- Name: transfer_period_group_ranges transfer_period_group_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_group_ranges
    ADD CONSTRAINT transfer_period_group_ranges_pkey PRIMARY KEY (id);


--
-- Name: transfer_period_regional_group_ranges transfer_period_regional_group_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_group_ranges
    ADD CONSTRAINT transfer_period_regional_group_ranges_pkey PRIMARY KEY (id);


--
-- Name: transfer_period_regional_prices transfer_period_regional_pric_transfer_period_id_sub_region_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_prices
    ADD CONSTRAINT transfer_period_regional_pric_transfer_period_id_sub_region_key UNIQUE (transfer_period_id, sub_region_id);


--
-- Name: transfer_period_regional_prices transfer_period_regional_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_prices
    ADD CONSTRAINT transfer_period_regional_prices_pkey PRIMARY KEY (id);


--
-- Name: vehicle_contracts unique_contract_code_per_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contracts
    ADD CONSTRAINT unique_contract_code_per_company UNIQUE (vehicle_company_id, contract_code);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicle_companies vehicle_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_companies
    ADD CONSTRAINT vehicle_companies_pkey PRIMARY KEY (id);


--
-- Name: vehicle_contract_routes vehicle_contract_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contract_routes
    ADD CONSTRAINT vehicle_contract_routes_pkey PRIMARY KEY (id);


--
-- Name: vehicle_contracts vehicle_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contracts
    ADD CONSTRAINT vehicle_contracts_pkey PRIMARY KEY (id);


--
-- Name: vehicle_types vehicle_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_types
    ADD CONSTRAINT vehicle_types_pkey PRIMARY KEY (id);


--
-- Name: costs_cost_code_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX costs_cost_code_active_unique ON public.costs USING btree (cost_code) WHERE (is_active = true);


--
-- Name: idx_action_regional_prices_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_action_regional_prices_action ON public.contract_action_regional_prices USING btree (action_id);


--
-- Name: idx_action_regional_prices_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_action_regional_prices_region ON public.contract_action_regional_prices USING btree (sub_region_id);


--
-- Name: idx_cities_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cities_name ON public.cities USING btree (name);


--
-- Name: idx_cities_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cities_region_id ON public.cities USING btree (region_id);


--
-- Name: idx_contract_actions_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_actions_contract_id ON public.contract_actions USING btree (contract_id);


--
-- Name: idx_contract_actions_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_actions_dates ON public.contract_actions USING btree (action_start_date, action_end_date);


--
-- Name: idx_contract_actions_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_actions_end_date ON public.contract_actions USING btree (action_end_date);


--
-- Name: idx_contract_actions_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_actions_start_date ON public.contract_actions USING btree (action_start_date);


--
-- Name: idx_contract_kickback_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_kickback_periods_contract_id ON public.contract_kickback_periods USING btree (contract_id);


--
-- Name: idx_contract_kickback_periods_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_kickback_periods_end_date ON public.contract_kickback_periods USING btree (end_date);


--
-- Name: idx_contract_kickback_periods_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_kickback_periods_start_date ON public.contract_kickback_periods USING btree (start_date);


--
-- Name: idx_contract_price_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_price_periods_contract_id ON public.contract_price_periods USING btree (contract_id);


--
-- Name: idx_contract_price_periods_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_price_periods_end_date ON public.contract_price_periods USING btree (end_date);


--
-- Name: idx_contract_price_periods_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_price_periods_start_date ON public.contract_price_periods USING btree (start_date);


--
-- Name: idx_contract_regional_prices_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_regional_prices_contract_id ON public.contract_regional_prices USING btree (contract_id);


--
-- Name: idx_contract_regional_prices_contract_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_regional_prices_contract_price ON public.contract_regional_prices USING btree (contract_id, adult_price DESC NULLS LAST);


--
-- Name: idx_contract_regional_prices_currency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_regional_prices_currency ON public.contract_regional_prices USING btree (adult_currency, child_currency, infant_currency);


--
-- Name: idx_contract_regional_prices_sub_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_regional_prices_sub_region ON public.contract_regional_prices USING btree (sub_region_id);


--
-- Name: idx_contract_regional_prices_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_regional_prices_sub_region_id ON public.contract_regional_prices USING btree (sub_region_id);


--
-- Name: idx_contract_transfer_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_transfer_periods_contract_id ON public.contract_transfer_periods USING btree (contract_id);


--
-- Name: idx_contract_transfer_periods_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_transfer_periods_end_date ON public.contract_transfer_periods USING btree (end_date);


--
-- Name: idx_contract_transfer_periods_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_transfer_periods_start_date ON public.contract_transfer_periods USING btree (start_date);


--
-- Name: idx_contracts_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_active ON public.contracts USING btree (is_active, start_date, end_date);


--
-- Name: idx_contracts_contract_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_contract_code ON public.contracts USING btree (contract_code);


--
-- Name: idx_contracts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_created_at ON public.contracts USING btree (created_at DESC);


--
-- Name: idx_contracts_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_dates ON public.contracts USING btree (start_date, end_date);


--
-- Name: idx_contracts_dates_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_dates_range ON public.contracts USING btree (start_date, end_date);


--
-- Name: idx_contracts_merchant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_merchant ON public.contracts USING btree (merchant_id);


--
-- Name: idx_contracts_merchant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_merchant_id ON public.contracts USING btree (merchant_id);


--
-- Name: idx_contracts_merchant_tour; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_merchant_tour ON public.contracts USING btree (merchant_id, tour_id);


--
-- Name: idx_contracts_price_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_price_type ON public.contracts USING btree (price_type);


--
-- Name: idx_contracts_sub_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_sub_region ON public.contracts USING btree (sub_region_id);


--
-- Name: idx_contracts_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_sub_region_id ON public.contracts USING btree (sub_region_id);


--
-- Name: idx_contracts_tour; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_tour ON public.contracts USING btree (tour_id);


--
-- Name: idx_contracts_tour_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_tour_id ON public.contracts USING btree (tour_id);


--
-- Name: idx_contracts_vehicle_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_vehicle_company ON public.contracts USING btree (vehicle_company_id);


--
-- Name: idx_costs_city_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_costs_city_id ON public.costs USING btree (city_id);


--
-- Name: idx_costs_cost_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_costs_cost_code ON public.costs USING btree (cost_code);


--
-- Name: idx_costs_country_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_costs_country_id ON public.costs USING btree (country_id);


--
-- Name: idx_costs_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_costs_region_id ON public.costs USING btree (region_id);


--
-- Name: idx_countries_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_countries_name ON public.countries USING btree (name);


--
-- Name: idx_currencies_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_currencies_active ON public.currencies USING btree (is_active);


--
-- Name: idx_currencies_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_currencies_code ON public.currencies USING btree (code);


--
-- Name: idx_departments_city_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_city_id ON public.departments USING btree (city_id);


--
-- Name: idx_departments_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_name ON public.departments USING btree (name);


--
-- Name: idx_kickback_periods_contract; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kickback_periods_contract ON public.contract_kickback_periods USING btree (contract_id);


--
-- Name: idx_kickback_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kickback_periods_contract_id ON public.contract_kickback_periods USING btree (contract_id);


--
-- Name: idx_kickback_periods_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kickback_periods_dates ON public.contract_kickback_periods USING btree (start_date, end_date);


--
-- Name: idx_merchants_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_merchants_id ON public.merchants USING btree (id);


--
-- Name: idx_merchants_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_merchants_name ON public.merchants USING btree (name);


--
-- Name: idx_merchants_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_merchants_sub_region_id ON public.merchants USING btree (sub_region_id);


--
-- Name: idx_positions_dept_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_positions_dept_id ON public.positions USING btree (department_id);


--
-- Name: idx_positions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_positions_name ON public.positions USING btree (name);


--
-- Name: idx_price_period_regional_prices_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_period_regional_prices_period ON public.contract_price_period_regional_prices USING btree (price_period_id);


--
-- Name: idx_price_period_regional_prices_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_period_regional_prices_region ON public.contract_price_period_regional_prices USING btree (sub_region_id);


--
-- Name: idx_price_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_periods_contract_id ON public.contract_price_periods USING btree (contract_id);


--
-- Name: idx_price_periods_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_price_periods_dates ON public.contract_price_periods USING btree (start_date, end_date);


--
-- Name: idx_regions_country_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_regions_country_id ON public.regions USING btree (country_id);


--
-- Name: idx_regions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_regions_name ON public.regions USING btree (name);


--
-- Name: idx_sub_regions_city_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_regions_city_id ON public.sub_regions USING btree (city_id);


--
-- Name: idx_sub_regions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_regions_id ON public.sub_regions USING btree (id);


--
-- Name: idx_sub_regions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_regions_name ON public.sub_regions USING btree (name);


--
-- Name: idx_tour_contract_routes_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tour_contract_routes_sub_region_id ON public.tour_contract_routes USING btree (sub_region_id);


--
-- Name: idx_tour_contract_routes_tour_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tour_contract_routes_tour_id ON public.tour_contract_routes USING btree (tour_id);


--
-- Name: idx_tour_contract_routes_vehicle_contract_route_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tour_contract_routes_vehicle_contract_route_id ON public.tour_contract_routes USING btree (vehicle_contract_route_id);


--
-- Name: idx_tour_sub_regions_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tour_sub_regions_sub_region_id ON public.tour_sub_regions USING btree (sub_region_id);


--
-- Name: idx_tour_sub_regions_tour_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tour_sub_regions_tour_id ON public.tour_sub_regions USING btree (tour_id);


--
-- Name: idx_tours_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_dates ON public.tours USING btree (start_date, end_date);


--
-- Name: idx_tours_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_id ON public.tours USING btree (id);


--
-- Name: idx_tours_merchant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_merchant_id ON public.tours USING btree (merchant_id);


--
-- Name: idx_tours_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_name ON public.tours USING btree (name);


--
-- Name: idx_tours_sejour_tour_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_sejour_tour_code ON public.tours USING btree (sejour_tour_code);


--
-- Name: idx_tours_sub_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_sub_region_id ON public.tours USING btree (sub_region_id);


--
-- Name: idx_tours_vehicle_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tours_vehicle_contract_id ON public.tours USING btree (vehicle_contract_id);


--
-- Name: idx_transfer_group_ranges_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_group_ranges_period ON public.transfer_period_group_ranges USING btree (transfer_period_id);


--
-- Name: idx_transfer_period_group_ranges_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_period_group_ranges_period_id ON public.transfer_period_group_ranges USING btree (transfer_period_id);


--
-- Name: idx_transfer_period_regional_group_ranges_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_period_regional_group_ranges_period_id ON public.transfer_period_regional_group_ranges USING btree (transfer_period_id);


--
-- Name: idx_transfer_period_regional_prices_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_period_regional_prices_period_id ON public.transfer_period_regional_prices USING btree (transfer_period_id);


--
-- Name: idx_transfer_periods_contract; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_periods_contract ON public.contract_transfer_periods USING btree (contract_id);


--
-- Name: idx_transfer_periods_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_periods_contract_id ON public.contract_transfer_periods USING btree (contract_id);


--
-- Name: idx_transfer_periods_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_periods_dates ON public.contract_transfer_periods USING btree (start_date, end_date);


--
-- Name: idx_transfer_regional_group_ranges_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_regional_group_ranges_period ON public.transfer_period_regional_group_ranges USING btree (transfer_period_id);


--
-- Name: idx_transfer_regional_group_ranges_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_regional_group_ranges_region ON public.transfer_period_regional_group_ranges USING btree (sub_region_id);


--
-- Name: idx_transfer_regional_prices_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_regional_prices_period ON public.transfer_period_regional_prices USING btree (transfer_period_id);


--
-- Name: idx_transfer_regional_prices_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_regional_prices_region ON public.transfer_period_regional_prices USING btree (sub_region_id);


--
-- Name: idx_users_city; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_city ON public.users USING btree (city_id);


--
-- Name: idx_users_department; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_department ON public.users USING btree (department_id);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_vehicle_companies_city_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_companies_city_id ON public.vehicle_companies USING btree (city_id);


--
-- Name: idx_vehicle_companies_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_companies_name ON public.vehicle_companies USING btree (name);


--
-- Name: idx_vehicle_contract_routes_contract; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_contract_routes_contract ON public.vehicle_contract_routes USING btree (vehicle_contract_id);


--
-- Name: idx_vehicle_contracts_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_contracts_active ON public.vehicle_contracts USING btree (is_active, start_date, end_date);


--
-- Name: idx_vehicle_contracts_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_contracts_code ON public.vehicle_contracts USING btree (contract_code);


--
-- Name: idx_vehicle_contracts_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_contracts_company ON public.vehicle_contracts USING btree (vehicle_company_id);


--
-- Name: idx_vehicle_contracts_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_contracts_dates ON public.vehicle_contracts USING btree (start_date, end_date);


--
-- Name: idx_vehicle_types_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_types_company_id ON public.vehicle_types USING btree (vehicle_company_id);


--
-- Name: idx_vehicle_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_types_name ON public.vehicle_types USING btree (name);


--
-- Name: vehicle_contracts trigger_archive_vehicle_contracts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_archive_vehicle_contracts BEFORE INSERT ON public.vehicle_contracts FOR EACH ROW EXECUTE FUNCTION public.archive_old_version();


--
-- Name: cities update_cities_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cities_updated_at BEFORE UPDATE ON public.cities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: costs update_costs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_costs_updated_at BEFORE UPDATE ON public.costs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: countries update_countries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_countries_updated_at BEFORE UPDATE ON public.countries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: departments update_departments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON public.departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: merchants update_merchants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_merchants_updated_at BEFORE UPDATE ON public.merchants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: positions update_positions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_positions_updated_at BEFORE UPDATE ON public.positions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: regions update_regions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_regions_updated_at BEFORE UPDATE ON public.regions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: sub_regions update_sub_regions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_sub_regions_updated_at BEFORE UPDATE ON public.sub_regions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tours update_tours_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_tours_updated_at BEFORE UPDATE ON public.tours FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicle_companies update_vehicle_companies_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_vehicle_companies_updated_at BEFORE UPDATE ON public.vehicle_companies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicle_types update_vehicle_types_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_vehicle_types_updated_at BEFORE UPDATE ON public.vehicle_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cities cities_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE CASCADE;


--
-- Name: contract_action_regional_prices contract_action_regional_prices_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_action_regional_prices
    ADD CONSTRAINT contract_action_regional_prices_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.contract_actions(id) ON DELETE CASCADE;


--
-- Name: contract_action_regional_prices contract_action_regional_prices_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_action_regional_prices
    ADD CONSTRAINT contract_action_regional_prices_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: contract_kickback_periods contract_kickback_periods_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_kickback_periods
    ADD CONSTRAINT contract_kickback_periods_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contract_price_period_regional_prices contract_price_period_regional_prices_price_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_period_regional_prices
    ADD CONSTRAINT contract_price_period_regional_prices_price_period_id_fkey FOREIGN KEY (price_period_id) REFERENCES public.contract_price_periods(id) ON DELETE CASCADE;


--
-- Name: contract_price_period_regional_prices contract_price_period_regional_prices_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_period_regional_prices
    ADD CONSTRAINT contract_price_period_regional_prices_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: contract_regional_prices contract_regional_prices_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_regional_prices
    ADD CONSTRAINT contract_regional_prices_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contract_regional_prices contract_regional_prices_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_regional_prices
    ADD CONSTRAINT contract_regional_prices_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: contract_transfer_periods contract_transfer_periods_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_transfer_periods
    ADD CONSTRAINT contract_transfer_periods_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: costs costs_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT costs_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: costs costs_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT costs_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id) ON DELETE CASCADE;


--
-- Name: costs costs_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costs
    ADD CONSTRAINT costs_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE CASCADE;


--
-- Name: departments departments_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: contract_actions fk_contract_actions_contract; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_actions
    ADD CONSTRAINT fk_contract_actions_contract FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contracts fk_contracts_merchant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_merchant FOREIGN KEY (merchant_id) REFERENCES public.merchants(id) ON DELETE CASCADE;


--
-- Name: contracts fk_contracts_sub_region; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_sub_region FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: contracts fk_contracts_tour; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_tour FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: contracts fk_contracts_vehicle_company; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT fk_contracts_vehicle_company FOREIGN KEY (vehicle_company_id) REFERENCES public.vehicle_companies(id);


--
-- Name: contract_price_periods fk_price_periods_contract; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_price_periods
    ADD CONSTRAINT fk_price_periods_contract FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: merchants merchants_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: positions positions_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: regions regions_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id) ON DELETE CASCADE;


--
-- Name: sub_regions sub_regions_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_regions
    ADD CONSTRAINT sub_regions_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: tour_contract_routes tour_contract_routes_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes
    ADD CONSTRAINT tour_contract_routes_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: tour_contract_routes tour_contract_routes_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes
    ADD CONSTRAINT tour_contract_routes_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tour_contract_routes tour_contract_routes_vehicle_contract_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_contract_routes
    ADD CONSTRAINT tour_contract_routes_vehicle_contract_route_id_fkey FOREIGN KEY (vehicle_contract_route_id) REFERENCES public.vehicle_contract_routes(id) ON DELETE CASCADE;


--
-- Name: tour_sub_regions tour_sub_regions_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_sub_regions
    ADD CONSTRAINT tour_sub_regions_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: tour_sub_regions tour_sub_regions_tour_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tour_sub_regions
    ADD CONSTRAINT tour_sub_regions_tour_id_fkey FOREIGN KEY (tour_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tours tours_merchant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES public.merchants(id) ON DELETE CASCADE;


--
-- Name: tours tours_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: tours tours_vehicle_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_vehicle_contract_id_fkey FOREIGN KEY (vehicle_contract_id) REFERENCES public.vehicle_contracts(id) ON DELETE SET NULL;


--
-- Name: transfer_period_group_ranges transfer_period_group_ranges_transfer_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_group_ranges
    ADD CONSTRAINT transfer_period_group_ranges_transfer_period_id_fkey FOREIGN KEY (transfer_period_id) REFERENCES public.contract_transfer_periods(id) ON DELETE CASCADE;


--
-- Name: transfer_period_regional_group_ranges transfer_period_regional_group_ranges_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_group_ranges
    ADD CONSTRAINT transfer_period_regional_group_ranges_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: transfer_period_regional_group_ranges transfer_period_regional_group_ranges_transfer_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_group_ranges
    ADD CONSTRAINT transfer_period_regional_group_ranges_transfer_period_id_fkey FOREIGN KEY (transfer_period_id) REFERENCES public.contract_transfer_periods(id) ON DELETE CASCADE;


--
-- Name: transfer_period_regional_prices transfer_period_regional_prices_sub_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_prices
    ADD CONSTRAINT transfer_period_regional_prices_sub_region_id_fkey FOREIGN KEY (sub_region_id) REFERENCES public.sub_regions(id) ON DELETE CASCADE;


--
-- Name: transfer_period_regional_prices transfer_period_regional_prices_transfer_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_period_regional_prices
    ADD CONSTRAINT transfer_period_regional_prices_transfer_period_id_fkey FOREIGN KEY (transfer_period_id) REFERENCES public.contract_transfer_periods(id) ON DELETE CASCADE;


--
-- Name: users users_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE SET NULL;


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: vehicle_companies vehicle_companies_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_companies
    ADD CONSTRAINT vehicle_companies_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: vehicle_contract_routes vehicle_contract_routes_vehicle_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contract_routes
    ADD CONSTRAINT vehicle_contract_routes_vehicle_contract_id_fkey FOREIGN KEY (vehicle_contract_id) REFERENCES public.vehicle_contracts(id) ON DELETE CASCADE;


--
-- Name: vehicle_contracts vehicle_contracts_vehicle_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_contracts
    ADD CONSTRAINT vehicle_contracts_vehicle_company_id_fkey FOREIGN KEY (vehicle_company_id) REFERENCES public.vehicle_companies(id) ON DELETE CASCADE;


--
-- Name: vehicle_types vehicle_types_vehicle_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_types
    ADD CONSTRAINT vehicle_types_vehicle_company_id_fkey FOREIGN KEY (vehicle_company_id) REFERENCES public.vehicle_companies(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict o89AaZRmdwlbKFgXBvZnm4G8fDpqh23x9T5u3W4eZ3WgbREqJuadjpFcGeByU0v

